#include "FPcommon.h"
#include "Annealer.h"
#include "ClusterDB.h"
#include "command_line.h"
#include "SolveMulti.h"

SolveMulti::SolveMulti(DB * db, Command_Line* params)
{
  _db = db;
  _params = params;
  _newDB = new DB();
}

SolveMulti::~SolveMulti()
{
  if(_newDB) delete _newDB;
}

void SolveMulti::go(void)
{
  ClusterDB multiCluster(_db, _params);

  if(_params->clusterPhysical)
    multiCluster.clusterMultiPhysical(_newDB);
  else
    multiCluster.clusterMulti(_newDB);

  cout<<"Num Nodes : "<<_newDB->getNumNodes()<<endl;

  double reqdWidth = 1e100;
  double reqdHeight = 1e100;
  double maxArea = (1+_params->maxWS/100)*_newDB->getNodesArea();

  if(_params->reqdAR != -9999)
    {
      reqdHeight = sqrt(maxArea/_params->reqdAR);
      reqdWidth = maxArea/reqdHeight;
    }
  double currXSize, currYSize;
  unsigned maxIter = 0;
  Annealer annealer(_params, _newDB);

  do
    {
      annealer.go();
      currXSize = annealer.getXSize();
      currYSize = annealer.getYSize();
      if(currXSize<=reqdWidth && currYSize<=reqdHeight)
	break;
      
      maxIter++;
      if(maxIter == 50)
	break;
    }
  while(1);

  updatePlaceUnCluster(_newDB);

  _newDB->plot("main.gpl", _newDB->evalArea(), 
	       100*(_newDB->evalArea()-_newDB->getNodesArea())/_newDB->getNodesArea(),
	       _newDB->getXSize()/_newDB->getYSize(), 0, _newDB->evalHPWL(), 
	       0, 0, 1);

  if(!_params->solveTop)
    placeSubBlocks();

  _db->plot("final.gpl", _db->evalArea(), 
	    100*(_db->evalArea()-_db->getNodesArea())/_db->getNodesArea(),
	       _db->getXSize()/_db->getYSize(), 0, _db->evalHPWL(), 
	       0, 0, 1);
}

void SolveMulti::placeSubBlocks(void)
{
  Nodes* nodes = _newDB->getNodes();
  Nodes* origNodes = _db->getNodes();

  itNode node;

  Command_Line* params = new Command_Line(*_params);
  params->budgetTime = 0;

  for(node=nodes->nodesBegin(); node!=nodes->nodesEnd(); ++node)
    {
      Point dbLoc;
      dbLoc.x = node->getX();
      dbLoc.y = node->getY();
      params->reqdAR = node->getWidth()/node->getHeight();

      DB * tempDB = new DB(_db, node->getSubBlocks(), dbLoc, params->reqdAR);

      cout<<node->getName()<<"\t"<<node->numSubBlocks()<<endl;

      Annealer annealer(params, tempDB);
      
      double currXSize, currYSize;
      double reqdWidth = node->getWidth();
      double reqdHeight = node->getHeight();

      unsigned maxIter = 0;
      do
	{
	  annealer.go();
	  currXSize = annealer.getXSize();
	  currYSize = annealer.getYSize();
	  if(currXSize<=reqdWidth && currYSize<=reqdHeight)
	    break;

	  maxIter++;
	  if(maxIter == 50)
	    break;
	}
      while(1);

      Point offset;
      offset.x = node->getX();
      offset.y = node->getY();
      
      tempDB->shiftDesign(offset);
 
      Nodes * tempNodes = tempDB->getNodes();

      for(itNode tempNode = tempNodes->nodesBegin(); 
	  tempNode != tempNodes->nodesEnd(); ++tempNode)
	{
	  for(vector<int>::iterator tempIdx = tempNode->subBlocksBegin();
	      tempIdx != tempNode->subBlocksEnd(); ++tempIdx)
	    {
	      Node& origNode = origNodes->getNode(*tempIdx);
	      origNode.putX(tempNode->getX());
	      origNode.putY(tempNode->getY());
	      origNode.changeOrient(tempNode->getOrient(), *(_db->getNets()));
	      origNode.putHeight(tempNode->getHeight());
	      origNode.putWidth(tempNode->getWidth());
	    }
	}
      delete tempDB;
    }
}

void SolveMulti::updatePlaceUnCluster(DB * clusterDB)
{
  Nodes* nodes = _db->getNodes();
  Nodes* newNodes = clusterDB->getNodes();

  itNode node;

  for(node = newNodes->nodesBegin(); node != newNodes->nodesEnd(); ++node)
    {
      for(vector<int>::iterator subBlockIdx = node->subBlocksBegin(); 
	  subBlockIdx != node->subBlocksEnd(); ++subBlockIdx)
	{
	  Node& tempNode = nodes->getNode(*subBlockIdx);
	  tempNode.putX(node->getX());
	  tempNode.putY(node->getY());
	  tempNode.changeOrient(node->getOrient(), *(_db->getNets()));
	}
      if(node->numSubBlocks() == 1)  //the only block
	{
	  vector<int>::iterator subBlockIdx = node->subBlocksBegin();
	  Node& tempNode = nodes->getNode(*subBlockIdx);
	  tempNode.putHeight(node->getHeight());
	  tempNode.putWidth(node->getWidth());
	}
    }
}






