#ifndef FPCOMMON
#define FPCOMMON

#include <string.h>
#include <iostream.h>
#include <iomanip.h>
#include <fstream.h>
#include <vector>
#include <algorithm>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "UTIL/timer.h"

using namespace std;

enum ORIENT {N, E, S, W, FN, FE, FS, FW};

struct Point
{
double x;
double y;
};

struct IntPoint
{
int x;
int y;
};

class BBox
{
 private:
  double _minX;
  double _maxX;
  double _minY;
  double _maxY;

  bool _valid;
  
 public:
  //ctor
  BBox();

  void put(Point& point);
  void clear(void);  
  double getHPWL(void);
  double getXSize(void);
  double getYSize(void);
  bool isValid(void);
};

//global parsing functions
void eatblank(ifstream& i);

void skiptoeol(ifstream& i);

void eathash(ifstream& i);

bool needCaseChar(ifstream& i, char character);

//functions to manage the orientations
ORIENT toOrient(char* orient);
char* toChar(ORIENT orient);
	
#endif



