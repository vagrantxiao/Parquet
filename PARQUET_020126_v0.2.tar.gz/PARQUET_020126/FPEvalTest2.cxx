#include "FPcommon.h"
#include "Annealer.h"
#include "command_line.h"
#include "UTIL/infolines.h"

int main(int argc, const char *argv[])
{
           double currXSize;
	   double currYSize;
	   double currArea = -1e100;
	   double lastArea;
	   double currWS;
	   double currWL;
	   double currAR=0;

	   Command_Line* params = new Command_Line(argc, argv);
	
	   DB* db = new DB(params->inFileName);
	   double blocksArea = db->getNodesArea();
	   
	   Annealer annealer(params, db);
	   annealer.eval();
	   currArea = annealer.getXSize()*annealer.getYSize();

	   if(params->initCompact)
	     {
	       bool whichDir = 0;
	       annealer.evalCompact(whichDir);
	       do
		 {
		   whichDir = !whichDir;
		   lastArea = currArea;
		   annealer.takeSPfromDB();
		   annealer.evalCompact(whichDir);
		   currArea = annealer.getXSize()*annealer.getYSize();
		   cout<<currArea<<"\t"<<lastArea<<endl;
		 }
	       while(int(currArea) < int(lastArea));
	     }

	   currXSize = annealer.getXSize();
	   currYSize = annealer.getYSize();
	   currArea = currXSize*currYSize;
	   currWS = 100*(currArea - blocksArea)/currArea;
 	   currWL = db->evalHPWL();
	   currAR = currXSize/currYSize;

	   if(params->plot)
	    {
	      currAR = currXSize/currYSize;
              bool plotSlacks = !params->plotNoSlacks;
              bool plotNets = !params->plotNoNets;
	      bool plotNames = !params->plotNoNames;
              db->plot("out.gpl", currArea, currWS, currAR, 0, 
	      		currWL, plotSlacks, plotNets, plotNames);
	    }
	    
           if(params->savePl)
	     db->getNodes()->savePl(params->outPlFile);
			      
	   if(params->saveCapo)
	     db->saveCapo(params->capoBaseFile, params->reqdAR);
	     
           cout<<"Final Area: "<<currArea<<" WhiteSpace "<<currWS<<"%"
	       <<" currAR "<<currAR<<" HPWL "<<currWL<<endl;
	  
	return 0;
}
