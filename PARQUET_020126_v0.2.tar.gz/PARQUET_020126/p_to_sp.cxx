#include <iostream>
#include <algorithm>
#include "p_to_sp.h"
using namespace std;

Position Boxes::second_in_term_of_first(vector<Box>::iterator first, 
	vector<Box>::iterator second)
{
	V_pos v;
	H_pos h;
	Position pos;

	if ((second->x+second->w) <= first->x)
		h=h_left;
	else if (second->x < (first->x + first->w))
		h=h_center;
	else
		h=h_right;

	if ((second->y + second->h) <= first->y)
		v=v_down;
	else if (second->y < (first->y + first->h))
		v=v_center;
	else
		v=v_top;

	if (v==v_top)
	{
		/*if (h==h_center)
			pos=p_top;
		else
			pos=special;*/

		if (h==h_left)
		{
			pos=p_top_left;
		}
		else if (h==h_center)
			pos=p_top;
		else
		{
			pos=p_top_right;
		}
	}
	else if (v==v_center)
	{
		if (h==h_left)
			pos=p_left;
		else if (h==h_center)
		{
			cerr<<"Overlap!\n";
			exit(1);
		}
		else
			pos=p_right;
	}
	else
	{
		/*if (h==h_center)
			pos=p_down;
		else
			pos=special;*/

		if (h==h_left)
		{
			pos=p_down_left;
		}
		else if (h==h_center)
			pos=p_down;
		else
		{
			pos=p_down_right;
		}
	}
	
	return pos;
}

	
Boxes::Boxes(Dit _xloc, Dit _yloc, Dit _w, Dit _h, int size)
{
	for (i=0; i < unsigned(size); i++)
	{
		temp.x=_xloc[i];
		temp.y=_yloc[i];
		temp.w=_w[i];
		temp.h=_h[i];

		box.push_back(temp);
	}

	v_graph.resize(size);
	h_graph.resize(size);
}

void Boxes::fill_graph()
{
	bool flag;

	//fill matrix with vertical contraint graph
	for (i=0; i<box.size(); i++)
	{
		//step 1 set identity matrix
		v_graph.set(i,i,true);

		//step 2 if this is the only block for the x-contraint
		//then set it as a false vertical constraint
		flag=false;
		for (j=0; j<box.size(); j++)
		{
			if ((box[j].x+box[j].w)==(box[i].x+box[i].w) && i != j)
			{
				flag=true;//there is another block set that constraint
			}
		}
		
		//step 3 check for vertical blocks
		for (j=0; j< box.size(); j++)
		{
			if ((box[j].x+box[j].w) > box[i].x && box[j].y >= (box[i].y+box[i].h))
			{
				if (box[j].x < (box[i].x+box[i].w))
					v_graph.set(j,i,true);
				else if (box[j].x == (box[i].x+box[i].w))
					v_graph.set(j,i,flag);
			}
		}
	}

	for (i=0; i<box.size(); i++)
	{
		//step 4 recursive iteration
		for (j=0; j< box.size(); j++)
		{
			if (v_graph.get(j,i))
			{
				v_graph.proj_col(j,i);
			}
		}
	}

	//get rit of the constrained boxes
	for (i=0; i<box.size(); i++)
	{
		for (j=0; j<box.size(); j++)
		{
			if (v_graph.get(j,i) && box[j].x ==(box[i].x+box[i].w))
			{
				if (j==6 && i==2)
					cout<<"star:\n";
				double temp=box[i].y;

				for (unsigned k=0; k<box.size(); k++)
				{
					if (box[j].x==(box[k].x+box[k].w) && box[j].y >= box[k].y)
					{

						if (box[k].y > temp)
							temp=box[k].y;
					}
				}

				if (temp==box[i].y)
				{
					v_graph.set(j,i,false);
				}
			}
		}
	}

	v_graph.print();
}

void Boxes::shaker(unsigned *l, unsigned *r, Dtype direction)
{
	bool swap, okay;
	unsigned *ptr;

	double max_x=0, max_y=0, AR;
	for (i=0; i < box.size(); i++)
	{
		if ((box[i].x+box[i].w) > max_x)
			max_x=(box[i].x+box[i].w);
		if ((box[i].y+box[i].h) > max_y)
			max_y=(box[i].y+box[i].h);
	}

	AR=max_x/max_y;

	while (l != r)
	{
		swap=false;

		for (ptr=l; ptr != r; ptr++)
		{
			pos=second_in_term_of_first(&box[*ptr],&box[*(ptr+1)]);
			if (direction==horizontal)
				if (pos==p_left || pos==p_top || pos==p_top_left)
					okay=false;
				else if (pos==p_top_right)
				{
					if (v_graph.get(*(ptr+1),*ptr))
						okay=false;
					else
						okay=true;
				}
				else if (pos==p_down_left)
				{
					if (v_graph.get(*ptr,*(ptr+1)))
						okay=true;
					else
						okay=false;
				}
				else
					okay=true;
			else
				if (pos==p_left || pos==p_down || pos==p_down_left)
					okay=false;
				else if (pos==p_top_left)
				{
					if (v_graph.get(*(ptr+1),*ptr))
						okay=true;
					else
						okay=false;
				}
				else if (pos==p_down_right)
				{
					if (v_graph.get(*ptr,*(ptr+1)))
						okay=false;
					else
						okay=true;
				}
				else
					okay=true;
			if (!okay)
			{
				exch(ptr, ptr+1);
				swap=true;
			}
		}

		r--;
		/*if (l==r) return;
		if (!swap) return;

		for (ptr=r; ptr != l; ptr--)
		{
			pos=second_in_term_of_first(&box[*ptr],&box[*(ptr-1)]);
			if (direction==horizontal)
				if (pos==p_left || pos==p_top || pos==p_top_left)
					okay=true;
				else if (pos==p_top_right)
				{
					if (v_graph.get(*(ptr-1),*ptr))
						okay=true;
					else
						okay=false;
				}
				else if (pos==p_down_left)
				{
					if (v_graph.get(*ptr,*(ptr-1)))
						okay=false;
					else
						okay=true;
				}
				else
					okay=false;
			else
				if (pos==p_left || pos==p_down || pos==p_down_left)
					okay=true;
				else if (pos==p_top_left)
				{
					if (v_graph.get(*(ptr-1),*ptr))
						okay=false;
					else
						okay=true;
				}
				else if (pos==p_down_right)
				{
					if (v_graph.get(*ptr,*(ptr-1)))
						okay=true;
					else
						okay=false;
				}
				else
					okay=false;
			if (!okay)
			{
				exch(ptr, ptr-1);
				swap=true;
			}
		}

		l++;*/
	}
}

void Boxes::exch(unsigned *idx, unsigned *idx1)
{
	unsigned temp;
	temp=*idx;
	*idx=*idx1;
	*idx1=temp;
}

Pl2SP_new::Pl2SP_new(vector<double>& xloc, vector<double>& yloc, vector<double>&
		     widths, vector<double>& heights): _xloc(xloc), _yloc(yloc),
		     _widths(widths), _heights(heights)
{
  unsigned size = _xloc.size();
  if(_yloc.size() != size || _widths.size() != size || _heights.size() != size)
  cout<<"ERROR: in Pl2SP_new. Sizes do not match"<<endl;

  _X.resize(size);
  _Y.resize(size);
  sp_merge(_X.begin(), _Y.begin(), _xloc.begin(), _yloc.begin(), _widths.begin()
  	   , _heights.begin(), size);

}


void Pl2SP_new::sp_merge(Uit X, Uit Y, Dit x, Dit y, Dit w, Dit h, int size)
{
	int i;

	//initialize the sequence pair
	for(i=0; i<size; i++)
	{
		X[i]=i;
		Y[i]=i;
	}

	Boxes my(x,y,w,h,size);

	my.fill_graph();
	my.shaker(X, X+size-1, horizontal);
	my.shaker(Y, Y+size-1, vertical);
}
