#include <vector>
#include <algorithm>
#include <math.h>
#include <stdlib.h>
#include "Nets.h"
#include "Nodes.h"


class DB
{
 private:
  Nodes* _nodes;
  Nets* _nets;
  
  Nodes* _nodesBestCopy;

  double _area;
  bool _initArea;

 public:
  bool successAR;
  DB(char* baseName);
  DB(DB * db, vector<int>& subBlocksIndices, Point& dbLoc, double reqdAR);
  DB(void);

  ~DB();

  DB& operator=(DB& db2);
  void clean(void);

  unsigned getNumNodes(void);
  Nodes* getNodes(void);
  Nets* getNets(void);

  vector<double> getNodeWidths();
  vector<double> getNodeHeights();
  vector<double> getXLocs();
  vector<double> getYLocs();

  double getNodesArea(void);

  void updatePlacement(vector<double>& xloc, vector<double>& yloc);
  void updateSlacks(vector<double>& xSlack, vector<double>& ySlack);
  void plot(char* fileName, double area, double whitespace, double aspectRatio,
      double time, double HPWL, bool plotSlacks, bool plotNets, bool plotNames);

  void saveCapo(char *baseFileName, double reqdAR);  //save the data in Capo format
  void saveCapoNets(char* baseFileName);

  void save(char* baseFileName); //save data in floorplan format
  void saveNets(char* baseFileName);

  void saveBestCopyPl(char* baseFileName);
  void saveInBestCopy(void);

  double evalHPWL(void);  //assumes that placement is updated
 //assumes that placement is updated & terminals to be moved to floorplan edges
  double evalHPWL(double xSize, double ySize);  
  double evalArea(void);  //assumes that placement is updated
  double getXSize(void);
  double getYSize(void);

  void shiftDesign(Point& offset); //shift the entire placement by an offset
};

