#include "FPcommon.h"
#include "Annealer.h"
#include "command_line.h"
#include "ClusterDB.h"
#include "SolveMulti.h"
#include "UTIL/infolines.h"

int main(int argc, const char *argv[])
{
        Timer T;
	T.stop();
	double totalTime=0;
	double successTime = 0;
	double successAvgWL = 0;
	double successAvgArea = 0;

	double minArea=1e100;
	double minWS=1e100;
	double minWL=1e100;
	double aveArea=0;
	double aveWS=0;
	double aveWL=0;
	double currArea;
	double lastArea;
	double currWS;
	double currWL;
	double currXSize;
	double currYSize;
	double successAR=0;
	
	Command_Line* params = new Command_Line(argc, argv);
	
	for (int i=0; i<params->iterations; i++)
	{
	   DB* db = new DB(params->inFileName);
	   double blocksArea = db->getNodesArea();
	   double reqdArea = (1+(params->maxWS/100))*blocksArea;
	   double reqdWidth = sqrt(reqdArea*params->reqdAR);
	   double reqdHeight = reqdWidth/params->reqdAR;
	   
	   T.start(0.0);

	   if(!params->solveMulti)
	     {
	       Annealer annealer(params, db);
	       if(params->initQP)
		 {
		   annealer.solveQP();
		   annealer.takeSPfromDB();
		 }
	       
	       if(params->initCompact)
		 {
		   annealer.eval();
		   currArea = annealer.getXSize()*annealer.getYSize();
		   bool whichDir = 0;
		   annealer.evalCompact(whichDir);
		   do
		     {
		       whichDir = !whichDir;
		       lastArea = currArea;
		       annealer.takeSPfromDB();
		       annealer.evalCompact(whichDir);
		       currArea = annealer.getXSize()*annealer.getYSize();
		     }
		   while(int(currArea) < int(lastArea));
		 }
	       annealer.go();
	     }
	   else
	     {
	       SolveMulti solveMulti(db, params);
	       solveMulti.go();
	       
	       if(params->compact)
		 {
		   //compact the design
		   Annealer annealer(params, db);
		   bool whichDir = 0;
		   annealer.takeSPfromDB();
		   annealer.eval();
		   currArea = annealer.getXSize()*annealer.getYSize();
		   annealer.evalCompact(whichDir);
		   do
		     {
		       whichDir = !whichDir;
		       lastArea = currArea;
		       annealer.takeSPfromDB();
		       annealer.evalCompact(whichDir);
		       currArea = annealer.getXSize()*annealer.getYSize();
		       cout<<currArea<<"\t"<<lastArea<<endl;
		     }
		   while(int(currArea) < int(lastArea));
		 }
	     }
	   T.stop();

	   totalTime += T.getUserTime();
	   currXSize = db->getXSize();
	   currYSize = db->getYSize();
	   currArea = currXSize*currYSize;
	   currWS = 100*(currArea - blocksArea)/currArea;
	   currWL = db->evalHPWL();
	   aveArea += currArea;
	   aveWS += currWS;
	   aveWL += currWL;
	   if(minArea > currArea)
	     minArea = currArea;
	   if(minWS > currWS)
	     minWS = currWS;
	   if(minWL > currWL)
	     minWL = currWL;

	   if(params->reqdAR != -9999 && ((currArea<=reqdArea && 
	      currXSize<=reqdWidth && currYSize<=reqdHeight) || db->successAR))
	      {
	        ++successAR;
		successTime += T.getUserTime();
		successAvgWL += currWL;
		successAvgArea += currArea;
	      }
	   //plot and save the best solution
	   if(fabs(minArea-currArea) < 0.0000001)
	    {
	      if(params->plot)
	      {
	        double currAR = currXSize/currYSize;
                bool plotSlacks = !params->plotNoSlacks;
                bool plotNets = !params->plotNoNets;
	        bool plotNames = !params->plotNoNames;
                db->plot("out.gpl", currArea, currWS, currAR, T.getUserTime(), 
	      	  	  currWL, plotSlacks, plotNets, plotNames);
	      }
	      if(params->savePl)
	        db->getNodes()->savePl(params->outPlFile);

	      if(params->saveCapoPl)
	        db->getNodes()->saveCapoPl(params->capoPlFile);

	      if(params->saveCapo)
	        db->saveCapo(params->capoBaseFile, params->reqdAR);
	      
	      if(db->successAR)
		db->saveBestCopyPl("best.pl");
	    }
	   cout<<endl;
	}
        aveArea /= params->iterations;
	aveWS /= params->iterations;
	aveWL /= params->iterations;
        totalTime /= params->iterations;
	successTime /= successAR;
	successAvgWL /= successAR;
	successAvgArea /= successAR;
	successAR /= params->iterations;
	
	cout<<endl<<"Average Area: "<<aveArea<<" Minimum Area: "<<minArea<<endl
	    <<"Average HPWL: "<<aveWL<<" Minimum HPWL: "<<minWL<<endl
	    <<"Average WhiteSpace: "<<aveWS<<"%"<<" Minimum WhiteSpace: "
	    <<minWS<<"%"<<endl
	    <<"Average Time: "<<totalTime<<endl;
	if(params->reqdAR != -9999)
	 {
	   cout<<endl<<"Success Rate of satisfying fixed outline: "
	       <<100*successAR<<" %"<<endl;
	   cout<<"Average Time for successfull AR runs: "<<successTime<<endl;
	   cout<<"Average Area for successfull AR runs: "<<successAvgArea<<endl;
	   cout<<"Average WL for successfull AR runs: "<<successAvgWL<<endl;
	 }

	return 0;
}





