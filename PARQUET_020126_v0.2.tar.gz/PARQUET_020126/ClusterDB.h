#include <vector>
#include <algorithm>
#include <math.h>
#include <stdlib.h>
#include <map>

using namespace std;
class DB;
class Command_Line;

class ClusterDB
{
 private:

  Command_Line *_params; //parameters
  DB *_db;        //just a pointer to base DB
  DB *_newDB;     //used in cluster
  DB *_oldDB;     //used in cluster

 public:

  ClusterDB(DB* db, Command_Line *params);
  ~ClusterDB();

  void clusterMulti(DB * newDB);

  void cluster1Layer(unsigned layerNum);
  void addNetsToNewDB(Nets* nets, Nets* newNets, Nodes* nodes, Nodes* newNodes,
		      map<unsigned, unsigned>& mapping);

  Node& getClosestNode(Node& currNode, Nodes* nodes, Nets* nets, 
		       vector<bool>& seenNodes);
  void addWSPerNode(void);

  void clusterMultiPhysical(DB * newDB); //cluster with physical constraints
};

struct sortNumConnections //sort connectivities
{
  bool operator()(IntPoint pt1, IntPoint pt2)
  {
    return (pt1.y < pt2.y);
  }
};
