#include <fstream.h>
#include <vector>
#include <algorithm>
#include <math.h>
#include <stdlib.h>
using namespace std;


class SPeval
{
 private:
  //buffers go in here
  vector<unsigned> _match;
  vector<double> _L;
  vector<unsigned> _reverseSeq;
  vector<unsigned> _X;
  vector<unsigned> _Y;
  vector<double> _heights;
  vector<double> _widths;

  vector< vector<bool> > _TCGMatrixHoriz;
  vector< vector<bool> > _TCGMatrixVert;

  double _lcsCompute(const vector<unsigned>& X,
		     const vector<unsigned>& Y,
		     const vector<double>& weights,
		     vector<unsigned>& match,
		     vector<double>& P,
		     vector<double>& L
		     );

  double _lcsReverseCompute(const vector<unsigned>& X,
			    const vector<unsigned>& Y,
			    const vector<double>& weights,
			    vector<unsigned>& match,
			    vector<double>& P,
			    vector<double>& L
			    );
  
  double _lcsComputeCompact(const vector<unsigned>& X,
			    const vector<unsigned>& Y,
			    const vector<double>& weights,
			    vector<unsigned>& match,
			    vector<double>& P,
			    vector<double>& L,
			    vector<double>& oppLocs,
			    vector<double>& oppWeights
			    );

 public:
  vector<double> xloc;
  vector<double> yloc;
  double xSize;
  double ySize;
  vector<double> xSlacks;
  vector<double> ySlacks;
  vector<double> xlocRev;
  vector<double> ylocRev;


  SPeval(const vector<double> heights, const vector<double> widths);

  
  void evaluate(vector<unsigned>& X, vector<unsigned>& Y);
  double xEval();
  double yEval();
  void evalSlacks(vector<unsigned>& X, vector<unsigned>& Y);
  double xEvalRev();
  double yEvalRev();

  void evaluateCompact(vector<unsigned>& X, vector<unsigned>& Y, 
		       bool whichDir);
  double xEvalCompact();
  double yEvalCompact();
  void computeConstraintGraphs();
  void removeRedundantConstraints(bool knownDir);
  void computeSPFromCG();

  void changeWidths(vector<double>& widths);
  void changeHeights(vector<double>& heights);
  void changeNodeWidth(unsigned index, double width);
  void changeNodeHeight(unsigned index, double height);
  void changeOrient(unsigned index);
};


