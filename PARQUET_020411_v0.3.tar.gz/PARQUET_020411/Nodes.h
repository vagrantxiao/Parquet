#include <vector>
#include <algorithm>
#include <math.h>
#include <stdlib.h>
#include "Node.h"

class Nets;
using namespace std;
typedef std::vector<Node>::iterator itNode;

class Nodes
{
 private:
  vector<Node> _nodes;
  vector<Node> _terminals;
  
 public:
  Nodes(char* baseName);
  Nodes(void)
    {}

  unsigned getNumNodes(void);

  void parseNodes(char* fnameBl);
  void parsePl(char* fnamePl);

  Node& getNode(unsigned index)
    { return _nodes[index]; }

  Node& getTerm(unsigned index)
    { return _terminals[index]; }

  void putNewNode(Node& node)
    { _nodes.push_back(node); }

  void putNewTerm(Node& term)
    { _terminals.push_back(term); }

  void clearNodes(void)
    { _nodes.resize(0); }

  void clearTerm(void)
    { _terminals.resize(0); }

  void clean(void)
    {
      _nodes.clear();
      _terminals.clear();
    }

  itNode nodesBegin(void)
    { return _nodes.begin(); }

  itNode nodesEnd(void)
    { return _nodes.end(); }


  unsigned getNumTerminals(void)
    { return _terminals.size(); }
  
  Node& getTerminal(unsigned index)
    { return _terminals[index]; }

  itNode terminalsBegin(void)
    { return _terminals.begin(); }
  itNode terminalsEnd(void)
    { return _terminals.end(); }
  
  vector<double> getNodeWidths();
  vector<double> getNodeHeights();
  vector<double> getXLocs();
  vector<double> getYLocs();
  double getNodeWidth(unsigned index);
  double getNodeHeight(unsigned index);
  double getNodesArea();
  double getMinHeight();

  void putNodeWidth(unsigned index, double width);
  void putNodeHeight(unsigned index, double height);

  void changeOrient(unsigned index, ORIENT newOrient, Nets& nets);
  void updatePinsInfo(Nets& nets);
 
  void updatePlacement(int index, bool type, double xloc, double yloc);
  void updateOrient(int index, bool type, ORIENT newOrient);
  void updateHW(int index, bool type, double width, double height);

  void savePl(char* baseFileName);
  void saveNodes(char* baseFileName);

  //following functions save in Capo format
  void saveCapoNodes(char* baseFileName);
  void saveCapoPl(char* baseFileName);
  void saveCapoScl(char* baseFileName, double reqdAR);
};
