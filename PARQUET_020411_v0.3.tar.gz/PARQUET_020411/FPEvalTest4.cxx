#include "FPcommon.h"
#include "Annealer.h"
#include "command_line.h"
#include "ClusterDB.h"
#include "SolveMulti.h"
#include "UTIL/infolines.h"

int main(int argc, const char *argv[])
{
           Timer T;
	   T.stop();
   	   double currArea, lastArea;
	   double currWS;
	   double currWL;
	   double currXSize;
	   double currYSize;
	   double currAR;

           Command_Line* params = new Command_Line(argc, argv);
	
	   DB* db = new DB(params->inFileName);
	   
	   T.start(0.0);
	   SolveMulti solveMulti(db, params);
	   solveMulti.go();

	   if(params->compact)
	     {
	       //compact the design
	       Annealer annealer(params, db);
	       bool whichDir = 0;
	       annealer.takeSPfromDB();
	       annealer.eval();
	       currArea = annealer.getXSize()*annealer.getYSize();
	       annealer.evalCompact(whichDir);
	       do
		 {
		   whichDir = !whichDir;
		   lastArea = currArea;
		   annealer.takeSPfromDB();
		   annealer.evalCompact(whichDir);
		   currArea = annealer.getXSize()*annealer.getYSize();
		   cout<<currArea<<"\t"<<lastArea<<endl;
		 }
	       while(int(currArea) < int(lastArea));
	     }
	   T.stop();

	   double blocksArea = db->getNodesArea();

	   currXSize = 0;
	   currYSize = 1;
	   currArea = db->evalArea();
	   currWS = 100*(currArea - blocksArea)/currArea;
	   currWL = db->evalHPWL();
	   currAR = currXSize/currYSize;

	   if(params->plot)
	     {
	       bool plotSlacks = !params->plotNoSlacks;
	       bool plotNets = !params->plotNoNets;
	       bool plotNames = !params->plotNoNames;
	       
	       db->plot("out.gpl", currArea, currWS, currAR, 
			T.getUserTime(), currWL, plotSlacks, plotNets, 
			plotNames);
	     }
	   if(params->save)
	     {
	       db->save(params->baseFile);
	     }
	return 0;
}
