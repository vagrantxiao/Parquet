#include <vector>
#include <algorithm>
#include <math.h>
#include <stdlib.h>

using namespace std;
class DB;

class SolveMulti
{
 private:
  
  DB * _db;
  Command_Line* _params;
  DB * _newDB;

 public:
  SolveMulti(DB * db, Command_Line* params);
  ~SolveMulti();
  void go(void);
  void placeSubBlocks(void);
  void updatePlaceUnCluster(DB * clusterDB);

};
