#include "FPcommon.h"

ostream& operator<<(ostream& out, const ORIENT& orient)
{
  if(orient == N)
    out<<"N";
  else if(orient == E)
    out<<"E";
  else if(orient == S)
    out<<"S";
  else if(orient == W)
    out<<"W";
  else if(orient == FN)
    out<<"FN";
  else if(orient == FE)
    out<<"FE";
  else if(orient == FS)
    out<<"FS";
  else if(orient == FW)
    out<<"FW";
  else
    cout<<"ERROR in outputting orientations"<<endl;
  return out;
}

BBox::BBox()
{
  _minX=(1e306);
  _maxX=(-1e306);
  _minY=(1e306);
  _maxY=(-1e306);
  _valid=0;
}

void BBox::clear(void)
{
  _minX=(1e306);
  _maxX=(-1e306);
  _minY=(1e306);
  _maxY=(-1e306);
  _valid=0;
}
void BBox::put(Point& point)
{
  if(point.x < _minX)
    _minX = point.x;
  if(point.x > _maxX)
    _maxX = point.x;
  if(point.y < _minY)
    _minY = point.y;
  if(point.y > _maxY)
    _maxY = point.y;
  _valid = 1;
}

double BBox::getHPWL(void)
{
  return((_maxX-_minX)+(_maxY-_minY));
}

double BBox::getXSize(void)
{ return(_maxX-_minX); }

double BBox::getYSize(void)
{ return(_maxY-_minY); }

bool BBox::isValid(void)
{
  return _valid;
}
void eatblank(ifstream& i)
{
  while (i.peek()==' ' || i.peek()=='\t') i.get();
}

void skiptoeol(ifstream& i)
{
  while (!i.eof() && i.peek()!='\n' && i.peek()!='\r') i.get();
  i.get();
}

bool needCaseChar(ifstream& i, char character)
{
  while(!i.eof() && i.peek() != character) i.get();
  if(i.eof())
    return 0;
  else
    return 1;
}
void eathash(ifstream& i)
{
  skiptoeol(i);
}

ORIENT toOrient(char* orient)
{
  if(!strcmp(orient, "N"))
    return N;
  if(!strcmp(orient, "E"))
    return E;
  if(!strcmp(orient, "S"))
    return S;
  if(!strcmp(orient, "W"))
    return W;
  if(!strcmp(orient, "FN"))
    return FN;
  if(!strcmp(orient, "FE"))
    return FE;
  if(!strcmp(orient, "FS"))
    return FS;
  if(!strcmp(orient, "FW"))
    return FW;

  cout<<"ERROR: in converting char* to ORIENT"<<endl;
  return N;
}

char* toChar(ORIENT orient)
{
  if(orient == N)
   { return("N"); }
  if(orient == E)
   { return("E"); }
  if(orient == S)
   { return("S"); }
  if(orient == W)
   { return("W"); }
  if(orient == FN)
   { return("FN"); }
  if(orient == FE)
   { return("FE"); }
  if(orient == FS)
   { return("FS"); }
  if(orient == FW)
   { return("FW"); }
  cout<<"ERROR: in converting ORIENT to char* "<<endl;
  return "N";
}
