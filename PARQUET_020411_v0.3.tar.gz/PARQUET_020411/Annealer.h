#include <fstream.h>
#include <vector>
#include <algorithm>
#include <math.h>
#include <stdlib.h>
#include "DB.h"
#include "SeqPair.h"
#include "SPeval.h"
#include "AnalSolve.h"

using namespace std;
class Command_Line;

class Annealer
{
 private:
  DB* _db;
  Command_Line* _params;
  SeqPair* _sp;
  SPeval* _spEval;
  AnalSolve* _analSolve;
  
  vector<Point> sortedXSlacks;
  vector<Point> sortedYSlacks;

  char _baseFileName[200];

 public:
  Annealer(){}
  Annealer(Command_Line* params, DB* db);

  ~Annealer();
  void parseConfig(void);

  void go(void);
  void anneal(void);
  void solveQP(void);  
  void takeSPfromDB(); //converts the present placement to a sequence pair
  
  void eval(void); //just evaluate the current SP and set up required data structures and values
  void evalCompact(bool whichDir); //just evaluate the current SP with compaction and set up required data structures and values

  int makeMove(vector<unsigned>& tempX, vector<unsigned>& tempY);
  int makeMoveSlacks(vector<unsigned>& tempX, vector<unsigned>& tempY);
  int makeMoveSlacksOrient(vector<unsigned>& A, vector<unsigned>& B,
		         unsigned& index, ORIENT& oldOrient, ORIENT& newOrient);
  int makeMoveOrient(unsigned& index, ORIENT& oldOrient, ORIENT& newOrient);
  int makeARMove(vector<unsigned>& A, vector<unsigned>& B, double currAR);
  int makeSoftBlMove(vector<unsigned>& A, vector<unsigned>& B,
		     unsigned &index, double &newWidth, double &newHeight);
  int makeIndexSoftBlMove(vector<unsigned>& A, vector<unsigned>& B,
	   	          unsigned index, double &newWidth, double &newHeight);

  int makeHPWLMove(vector<unsigned>& tempX, vector<unsigned>& tempY);
  int makeARWLMove(vector<unsigned>& tempX, vector<unsigned>& tempY, 
		   double currAR);

  void sortSlacks(vector<Point>& sortedXSlacks, vector<Point>& sortedYSlacks);

  double getXSize(void);      //requires that spEvaluations be done earlier
  double getYSize(void);      //requires that spEvaluations be done earlier

  int packSoftBlocks(unsigned numIter);
};

//used for std::sort function to sort slacks
struct sort_slacks
{
  bool operator()(Point pt1, Point pt2)
  {
    return (pt1.x < pt2.x);
  }
};

