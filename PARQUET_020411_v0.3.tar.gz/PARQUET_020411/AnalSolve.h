#include <stdlib.h>

using namespace std;
class Command_Line;

class AnalSolve
{
 private:
  Command_Line* _params;
  DB* _db;

  vector<double> _xloc;
  vector<double> _yloc;

 public:
  AnalSolve(){}
  AnalSolve(Command_Line* params, DB* db);
  ~AnalSolve(){}

  Point getOptLoc(int index, vector<double>& xloc, vector<double>& yloc);
                                                  //location of cells passed
  Point getDesignOptLoc();  //get the optimum location of the entire placement

  vector<double>& getXLocs()
   { return _xloc; }
  
  vector<double>& getYLocs()
   { return _yloc; }

  void solveSOR();  //uses the DB placements as initial solution
};

