#include "FPcommon.h"
#include "Annealer.h"
#include "command_line.h"
#include "UTIL/infolines.h"

int main(int argc, const char *argv[])
{
           double currXSize;
	   double currYSize;
	   double currArea;
	   double currWS;
	   double currWL;
	   double currAR=0;

	   Command_Line* params = new Command_Line(argc, argv);
	
	   DB* db = new DB(params->inFileName);
	   double blocksArea = db->getNodesArea();
	   
	   if(params->takePl)
	     {
	       Annealer annealer(params, db);
	       annealer.takeSPfromDB();
	       annealer.eval();
	     }

	   currXSize = db->getXSize();
	   currYSize = db->getYSize();
	   currArea = db->evalArea();
	   currWS = 100*(currArea - blocksArea)/currArea;
 	   currWL = db->evalHPWL();

	   if(params->plot)
	    {
	      currAR = currXSize/currYSize;
              bool plotSlacks = !params->plotNoSlacks;
              bool plotNets = !params->plotNoNets;
	      bool plotNames = !params->plotNoNames;
              db->plot("out.gpl", currArea, currWS, currAR, 0, 
	      		currWL, plotSlacks, plotNets, plotNames);
	    }
	    
           if(params->savePl)
	     db->getNodes()->savePl(params->outPlFile);
			      
	   if(params->saveCapo)
	     db->saveCapo(params->capoBaseFile, params->reqdAR);

	   if(params->save)
	     db->save(params->baseFile);

           cout<<"Final Area: "<<currArea<<" WhiteSpace "<<currWS<<"%"
	       <<" currAR "<<currAR<<" HPWL "<<currWL<<endl;
	   cout<<"blocksArea: "<<blocksArea<<endl; 
	return 0;
}
