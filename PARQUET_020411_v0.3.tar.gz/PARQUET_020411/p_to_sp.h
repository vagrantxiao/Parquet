#ifndef P_TO_SP
#define P_TO_SP

#include <vector>
using namespace std;

typedef enum{p_top, p_down, p_left, p_right,p_top_right, p_top_left,
	p_down_left, p_down_right,p_center,special} Position;
typedef enum{v_top, v_center, v_down} V_pos;
typedef enum{h_left, h_center, h_right} H_pos;
typedef enum{horizontal, vertical} Dtype;

typedef vector<unsigned>::iterator Uit;
typedef vector<double>::iterator Dit;

class Bool_Matrix
{
	typedef bool* boolptr;
	boolptr *graph;
	int dim, col, row;
	vector<bool> column;
public:
	Bool_Matrix(){};

	//only do resize once, otherwise: memory leak
	void resize(int size)//remember, resize is sort like a constructor
	{
		dim=size;

		graph=new boolptr[dim];
		for (row=0; row<dim; row++)
			*(graph+row)=new bool[dim];
		
		for(row=0; row<dim; row++)
			for(col=0; col<dim; col++)
				*(*(graph+row)+col)=false;

		column.resize(size);
	}//constructor

	~Bool_Matrix()
	{
		for (row=0; row<dim; row++)
			delete [] *(graph+row);

		delete [] graph;
	}

	void print()
	{
		cout<<"Matrix:\n";
		for(row=dim-1; row>=0; row--)
		{
			cout<<row<<"\t";
			for(col=0; col<dim; col++)
			{
				cout<<*(*(graph+row)+col)<<" ";
			}
			cout<<endl;
		}
		cout<<endl;
	}

	void set(int _row, int _col, bool val)
	{
		*(*(graph+_row)+_col)=val;
	}

	bool get(int _row, int _col)
	{
		return *(*(graph+_row)+_col);
	}

	void proj_row(int source, int dest)
	{
		for (col=0; col<dim; col++)
		{
			if (get(source,col))
				set(dest,col,true);
		}
	}

	void proj_col(int source, int dest)
	{
		for (row=0; row<dim; row++)
		{
			if (get(row,source))
				set(row,dest,true);
		}
	}

	void scan_delete(int _row, int _col)
	{

		fill(column.begin(),column.end(),true);

		for (unsigned i=0; i<column.size(); i++)
		{
			for (unsigned j=0; j<column.size(); j++)
			{
				if (get(j,i) != get(j,_col) && i != j)
				{
					column[j]=false;
				}
			}
		}

	}

};

class Box
{
public:
	double x,y,w,h;

	void print(){cout<<x<<" "<<y<<" "<<w<<" "<<h<<endl;}
};

class Boxes
{
	vector<Box> box;
	Dit _xloc, _yloc, _w, _h;
	int size;
	Bool_Matrix v_graph, h_graph;

	//temp variables
	Box temp;
	Position pos;
	unsigned i,j;

	void exch(unsigned *idx, unsigned *idx1);

public:
	Boxes(Dit _xloc, Dit _yloc, Dit _w, Dit _h, int size);

	void fill_graph();
	void shaker(unsigned *l, unsigned *r, Dtype direction);

	Position second_in_term_of_first(vector<Box>::iterator first, 
		vector<Box>::iterator second);
};


class Pl2SP_new
{
 private:
   vector<double> _xloc;
   vector<double> _yloc;
   vector<double> _widths;
   vector<double> _heights;

   vector<unsigned> _X;
   vector<unsigned> _Y;

 public:
   Pl2SP_new(vector<double>& xloc, vector<double>& yloc, vector<double>& widths,
	     vector<double>& heights);

  ~Pl2SP_new() {}

  vector<unsigned>& getXSP(void)
    { return _X; }

  vector<unsigned>& getYSP(void)
    { return _Y; }

  void sp_merge(Uit X, Uit Y, Dit x, Dit y, Dit w, Dit h, int size);
};


#endif
