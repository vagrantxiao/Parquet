#include "FPcommon.h"
#include "SeqPair.h"

SeqPair::SeqPair(unsigned size) //ctor randomly generates the seqPair
{
  _X.resize(size);
  _Y.resize(size);
  for(unsigned i=0; i<size; ++i)
    {
      _X[i] = i;
      _Y[i] = i;
    }
  random_shuffle(_X.begin(),_X.end());
  random_shuffle(_Y.begin(),_Y.end());
}

SeqPair::SeqPair(vector<unsigned>& X, vector<unsigned>& Y):_X(X), _Y(Y)
{
  if(X.size() != Y.size())
    cout<<"ERROR: Input Sequence Pairs of different sizes"<<endl;
}

vector<unsigned>& SeqPair::getX(void)
{
  return _X;
}

vector<unsigned>& SeqPair::getY(void)
{
  return _Y;
}

void SeqPair::putX(vector<unsigned>& X)
{ _X = X; }

void SeqPair::putY(vector<unsigned>& Y)
{ _Y = Y; }

unsigned SeqPair::getSize(void)
{  return _X.size(); }

void SeqPair::printX(void)
{
  cout<<"X Seq Pair"<<endl;
  for(unsigned i=0; i<_X.size(); ++i)
    {
      cout<<_X[i]<<" ";
    }
  cout<<endl;
}

void SeqPair::printY(void)
{
  cout<<"Y Seq Pair"<<endl;
  for(unsigned i=0; i<_X.size(); ++i)
    {
      cout<<_Y[i]<<" ";
    }
  cout<<endl;
}
