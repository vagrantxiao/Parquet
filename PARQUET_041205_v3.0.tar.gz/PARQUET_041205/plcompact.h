/**************************************************************************
***    
*** Copyright (c) 2000-2004 Regents of the University of Michigan,
***               Saurabh N. Adya, Hayward H. Chan and Igor L. Markov
***
***  Contact author(s): sadya@eecs.umich.edu, imarkov@umich.edu
***
***  Permission is hereby granted, free of charge, to any person obtaining 
***  a copy of this software and associated documentation files (the
***  "Software"), to deal in the Software without restriction, including
***  without limitation 
***  the rights to use, copy, modify, merge, publish, distribute, sublicense, 
***  and/or sell copies of the Software, and to permit persons to whom the 
***  Software is furnished to do so, subject to the following conditions:
***
***  The above copyright notice and this permission notice shall be included
***  in all copies or substantial portions of the Software.
***
*** THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
*** EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
*** OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
*** IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
*** CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT
*** OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
*** THE USE OR OTHER DEALINGS IN THE SOFTWARE.
***
***
***************************************************************************/






#ifndef PLCOMPACT_H
#define PLCOMPACT_H

#include "basepacking.h"

#include <iostream>
#include <vector>
using namespace std;

// --------------------------------------------------------
// back-end database to determine how much a block can/has to move
// *** NOT INTENDED TO BE USED DIRECTLY, USE ShiftLegalizer INSTEAD ***
class ShiftBlock
{
public:
   ShiftBlock(const vector<double>& xloc,
              const vector<double>& yloc,
              const vector<double>& widths,
              const vector<double>& heights,
              double left_bound,
              double right_bound,
              double top_bound,
              double bottom_bound);

   class ShiftInfo
   {
   public:
      double shiftRangeMin; 
      double shiftRangeMax;      
      double overlapMin;
      double overlapMax;
   };
   void operator ()(int currBlk,
                    vector<ShiftInfo>& shiftinfo) const; // 4-elt vector

   enum Directions {NORTH, EAST, SOUTH, WEST, DIR_NUM};
   static const double INFTY;
   static const double NEG_INFTY;
   static const int UNDEFINED;

private:
   int _blocknum;
   vector<double> _xStart;
   vector<double> _xEnd;
   vector<double> _yStart;
   vector<double> _yEnd;

   double _epsilon;
};
// --------------------------------------------------------
// front-end legalizer to be used
class ShiftLegalizer
{
public:
   ShiftLegalizer(const vector<double>& n_xloc,
                  const vector<double>& n_yloc,
                  const vector<double>& n_widths,
                  const vector<double>& n_heights,
                  double left_bound,
                  double right_bound,
                  double top_bound,
                  double bottom_bound);

   enum AlgoType {NAIVE};
   
   bool legalizeAll(AlgoType algo,
                    const vector<int>& checkBlks,
                    vector<int>& badBlks);   

   bool naiveLegalize(const vector<int>& checkBlks,
                      vector<int>& badBlks); // "t" ~ badBlks.empty() 
   bool legalizeBlock(int currBlk); // "t" ~ "currBlk" not overlap

   void putBlockIntoCore(int currBlk);

   inline const vector<double>& xloc() const;
   inline const vector<double>& yloc() const;
   inline const vector<double>& widths() const;
   inline const vector<double>& heights() const;

   inline double leftBound() const;
   inline double rightBound() const;
   inline double topBound() const;
   inline double bottomBound() const;

   static const double INFTY;
   static const int UNDEFINED;

   class ShiftRotateDecision
   {
   public:
      inline ShiftRotateDecision();
      
      bool rotate;
      int shiftDir;
      double shiftExtent;
   };
   bool shiftDecider(ShiftBlock::Directions currDir,
                     const vector<ShiftBlock::ShiftInfo>& shiftinfo,
                     ShiftRotateDecision& decision) const;
   bool rotateDecider(int currBlk,
                      const vector<ShiftBlock::ShiftInfo>& shiftinfo,
                      ShiftRotateDecision& decision) const;                            
   
private:
   int _blocknum;
   vector<double> _xloc;
   vector<double> _yloc;
   vector<double> _widths;
   vector<double> _heights;
   double _epsilon;

   const double _leftBound;
   const double _rightBound;
   const double _topBound;
   const double _bottomBound;

   void adjustBlock(int currBlk, const ShiftRotateDecision& decision);
};
void OutputShiftInfo(ostream& outs,
                     const vector<ShiftBlock::ShiftInfo>& shiftinfo);
// --------------------------------------------------------

// ===============
// IMPLEMENTATIONS
// ===============
const vector<double>& ShiftLegalizer::xloc() const
{   return _xloc; }
// --------------------------------------------------------
const vector<double>& ShiftLegalizer::yloc() const
{   return _yloc; }
// --------------------------------------------------------
const vector<double>& ShiftLegalizer::widths() const
{   return _widths; }
// --------------------------------------------------------
const vector<double>& ShiftLegalizer::heights() const
{   return _heights; }
// --------------------------------------------------------
double ShiftLegalizer::leftBound() const
{   return _leftBound; }
// --------------------------------------------------------
double ShiftLegalizer::rightBound() const
{   return _rightBound; }
// --------------------------------------------------------
double ShiftLegalizer::topBound() const
{   return _topBound; }
// --------------------------------------------------------
double ShiftLegalizer::bottomBound() const
{   return _bottomBound; }
// --------------------------------------------------------
ShiftLegalizer::ShiftRotateDecision::ShiftRotateDecision()
   : rotate(false),
     shiftDir(UNDEFINED),
     shiftExtent(INFTY)
{}
// --------------------------------------------------------

#endif
