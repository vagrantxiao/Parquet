This folder contains the MILP models and the benchmark used in the following paper:

Rabozzi, M., Lillis, J., and Santambrogio, M. D.: 
Floorplanning for partially-reconfigurable fpga systems via mixed-integer linear programming. 
In Field-Programmable Custom Computing Machines (FCCM), 2014 IEEE 22nd Annual International Symposium on, pages 186–193. IEEE, 2014.

################################ Folder Content

./readme.txt			This file
./floorplan.mod 		Contains the MILP model formulation for HO and O written using the GNU MathProg language
./benchmark/ 			Contains the synthetic benchmarks used in the paper
./examples/				Contains an example for the O model and an example for the HO model

################################ Software requirements

In order to compile the problems and convert them into a standard format for
linear programming optimization such as .mps or .lp it is neccessary to install
glpk solver:

https://www.gnu.org/software/glpk/

The model can then be solved directly with glpk or by another solver such as Gurobi or Cplex

################################ Running the examples under linux

The example folder contains three files:
./example/Virtex-5-XC5VLX110T.dat	A description of the Virtex-5-XC5VLX110T FPGA
./example/O_example.dat				Example problem for O model
./example/HO_example.dat			Example problem for HO model

To run an example directly from glpk writing the solution in "solution.sol" use this command (assuming glpk is in PATH):

glpsol -m floorplan.mod -d ./examples/Virtex-5-XC5VLX110T.dat -d ./examples/O_example.dat -o solution.sol

To compile the problem into a .lp file format use the following command:

glpsol -m floorplan.mod -d ./examples/Virtex-5-XC5VLX110T.dat -d ./examples/O_example.dat --check --wlp LP_FILE_PROBLEM.lp

To compile the problem into a .mps file format use the following command:

glpsol -m floorplan.mod -d ./examples/Virtex-5-XC5VLX110T.dat -d ./examples/O_example.dat --check --wmps LP_FILE_PROBLEM.mps

################################ Running the benchmark under linux

The benchmark folder contains these files
./example/base.dat		A description of the Virtex-5-XC5VLX110T FPGA and the objective function settings
./example/5_70.dat		problem with 5 regions and 70% of device occupancy
./example/5_75.dat		problem with 5 regions and 75% of device occupancy
[...]
./example/25_85.dat		problem with 25 regions and 85% of device occupancy


Running an example using glpk is not recommanded, it takes a large amount of time. Use Gurobi or Cplex instead.
If required, to run an example directly from glpk writing the solution in "solution.sol" use this command (assuming glpk is in PATH):

glpsol -m floorplan.mod -d ./benchmark/base.dat -d ./benchmark/5_70.dat -o solution.sol

To compile the problem into a .lp file format use the following command:

glpsol -m floorplan.mod -d ./benchmark/base.dat -d ./benchmark/5_70.dat --check --wlp LP_FILE_PROBLEM.lp

To compile the problem into a .mps file format use the following command:

glpsol -m floorplan.mod -d ./benchmark/base.dat -d ./benchmark/5_70.dat --check --wmps LP_FILE_PROBLEM.mps


For instances with a high number of reconfigurable regions it is highly recommanded to start the solver with a first feasible solution.
To do so, in Gurobi Optimizer the following command can be used

gurobi_cl InputFile=initial_solution.mst ResultFile=final_solution.sol problem_file.lp

initial_solution.mst has to contain an assignment for all the integer variables in the model
