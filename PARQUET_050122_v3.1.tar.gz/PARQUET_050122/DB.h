/**************************************************************************
***    
*** Copyright (c) 1995-2000 Regents of the University of California,
***               Andrew E. Caldwell, Andrew B. Kahng and Igor L. Markov
*** Copyright (c) 2000-2004 Regents of the University of Michigan,
***               Saurabh N. Adya, Jarrod A. Roy and Igor L. Markov
***
***  Contact author(s): abk@cs.ucsd.edu, imarkov@umich.edu
***  Original Affiliation:   UCLA, Computer Science Department,
***                          Los Angeles, CA 90095-1596 USA
***
***  Permission is hereby granted, free of charge, to any person obtaining 
***  a copy of this software and associated documentation files (the
***  "Software"), to deal in the Software without restriction, including
***  without limitation 
***  the rights to use, copy, modify, merge, publish, distribute, sublicense, 
***  and/or sell copies of the Software, and to permit persons to whom the 
***  Software is furnished to do so, subject to the following conditions:
***
***  The above copyright notice and this permission notice shall be included
***  in all copies or substantial portions of the Software.
***
*** THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
*** EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
*** OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
*** IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
*** CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT
*** OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
*** THE USE OR OTHER DEALINGS IN THE SOFTWARE.
***
***
***************************************************************************/














#ifndef DB_H
#define DB_H

#include <vector>
#include <algorithm>
#include <math.h>
#include <stdlib.h>
#include "Nets.h"
#include "Nodes.h"


namespace parquetfp
{
   class DB
   {
   protected:
      Nodes* _nodes;
      Nets* _nets;
  
      Nodes* _nodesBestCopy;

      // cached copies of sum(area of all nodes)
      mutable double _area;
      mutable bool _initArea;

      double _rowHeight;   //rowHeight to snap the soln to
      double _siteSpacing; //site spacing to snap the soln to

   public:
      bool successAR;
      DB(char* baseName);
      DB(DB * db, vector<int>& subBlocksIndices, Point& dbLoc, double reqdAR);
      DB(void);

      //makes a copy of db2. compresses multiple 2-pin nets
      //between modules regardless of pin-offset. use only when pin-offsets
      //are inconsequential
      DB(DB& db2, bool compressDB=false);

      ~DB();

      DB& operator=(DB& db2);
      void clean(void);

      unsigned getNumNodes(void) const;
      Nodes* getNodes(void);
      Nets* getNets(void);

      vector<double> getNodeWidths() const;
      vector<double> getNodeHeights() const;
      vector<double> getXLocs() const;
      vector<double> getYLocs() const;

      // hhchan: more efficient (safer) getters 
      inline double getNodeArea(unsigned index) const;
      inline double getNodeWidth(unsigned index) const;
      inline double getNodeHeight(unsigned index) const;
      inline double getXLoc(unsigned index) const;
      inline double getYLoc(unsigned index) const;
      inline ORIENT getOrient(unsigned index) const;

      inline double getNodeMaxAR(unsigned index) const;
      inline double getNodeMinAR(unsigned index) const;
      inline double getNodeAR(unsigned index) const;

      inline bool isMacro(unsigned index) const;
      inline bool isOrientFixed(unsigned index) const;
      inline bool isNodeSoft(unsigned index) const;
      inline bool isNodeHard(unsigned index) const;

      // hhchan: safer setters
      inline void setNodeWidth(unsigned index, double width);
      inline void setNodeHeight(unsigned index, double height);
      inline void setNodeAR(unsigned index, double ar);
      
      inline void setXLoc(unsigned index, double newX);
      inline void setYLoc(unsigned index, double newY);
      inline void setOrient(unsigned index,
                            ORIENT newOrient, bool ignoreNets = false);
      inline void setOrient(unsigned index,
                            const char* newOrient, bool ignoreNets = false);

      Point getBottomLeftCorner() const;
      Point getTopRightCorner() const;

      // pack to one of the corners
      // - use only interface fcns of SPeval, hence not efficient at all
      // - not meant to used in the critical loop
      // WARNING: assume the vectors of of size [NUM_CORNERS][getNumNodes()]
      enum Corner {BOTTOM_LEFT, BOTTOM_RIGHT, TOP_LEFT, TOP_RIGHT, NUM_CORNERS};
      inline static string toString(Corner corner);
      void packToCorner(vector< vector<double> >& xlocsAt,
                        vector< vector<double> >& ylocsAt) const;

      // optimize HPWL by the corner
      void cornerOptimizeDesign();

      // get total area of ALL nodes
      double getNodesArea(void) const;
      double getRowHeight(void) const;
      double getSiteSpacing(void) const;
      void setRowHeight(double rowHeight);
      void setSiteSpacing(double siteSpacing);

      // slim:       xloc, yloc, orient, width, height (but not the orig's)
      // location:   xloc, yloc
      // dimensions: width, height (but not the orig's)
      // TRUE ~ succeed in updating, FALSE otherwise
      inline bool updateNodeSlim(int index, const Node& newNode);
      inline bool updateNodeLocation(int index,
                                     double xloc, double yloc);
      inline bool updateNodeDimensions(int index,
                                       double width, double height);
      
      void updatePlacement(const vector<double>& xloc,
                           const vector<double>& yloc);
      void initPlacement(const Point& loc);      
      void updateSlacks(const vector<double>& xSlack,
                        const vector<double>& ySlack);

      // plot in gnuplot format
      void plot(char* fileName, double area, double whitespace, double aspectRatio,
                double time, double HPWL,
                bool plotSlacks, bool plotNets, bool plotNames) const;

      // save the data in Capo format
      void saveCapo(char *baseFileName, double reqdAR=1, double reqdWS=30) const;  
      void saveCapoNets(char* baseFileName) const;

      // save data in floorplan format
      void save(char* baseFileName) const; 
      void saveNets(char* baseFileName) const;
      void saveWts(char* baseFileName) const;

      void saveBestCopyPl(char* baseFileName) const;
      void saveInBestCopy(void); // non-const since it modifies "successAR"

      double evalHPWL(bool useWts=true) const;  //assumes that placement is updated
      //assumes that placement is updated & terminals to be moved to floorplan edges
      double evalHPWL(double xSize, double ySize, bool useWts=true) const;
      double evalArea(void) const;  //assumes that placement is updated
      double getXSize(void) const;
      double getYSize(void) const;
      double getAvgHeight(void) const;

      // optimize the BL-corner of the design
      void shiftOptimizeDesign(double outlineWidth,
                               double outlineHeight); // deduce BL-corner from DB
      void shiftOptimizeDesign(const Point& bottomLeft,
                               const Point& topRight); 
      
      void shiftDesign(Point& offset); //shift the entire placement by an offset

      void expandDesign(double maxWidth, double maxHeight);
      //expand entire design to occupy the new dimensions. only locations of blocks
      //are altered
  
      //marks all nodes with height > avgHeight as macros
      void markTallNodesAsMacros(double maxHeight);

      //reduce the core cells area of design excluding macros to maxWS whitespace
      //assumes macros are marked using DB::markTallNodesAsMacros()
      void reduceCoreCellsArea(double layoutArea, double maxWS);

      //this function gets the dimension of the FP only considering the macros
      double getXSizeWMacroOnly();
      double getYSizeWMacroOnly();

      double getXMaxWMacroOnly();
      double getYMaxWMacroOnly();

   private:
      // help function of shiftOptimizeDesign()
      double getOptimalRangeStart(bool isHorizontal);
   };

   // ---------------
   // IMPLEMENTATIONS
   // ---------------
   double DB::getNodeArea(unsigned index) const
   {   return getNodeWidth(index) * getNodeHeight(index); }
   
   double DB::getNodeWidth(unsigned index) const
   {   return _nodes->getNodeWidth(index); }

   double DB::getNodeHeight(unsigned index) const
   {   return _nodes->getNodeHeight(index); }

   double DB::getXLoc(unsigned index) const
   {   return (_nodes->getNode(index)).getX(); }

   double DB::getYLoc(unsigned index) const
   {   return (_nodes->getNode(index)).getY(); }

   ORIENT DB::getOrient(unsigned index) const
   {   return (_nodes->getNode(index)).getOrient(); }

   double DB::getNodeMinAR(unsigned index) const
   {   return (_nodes->getNode(index)).getminAR(); }

   double DB::getNodeMaxAR(unsigned index) const
   {   return (_nodes->getNode(index)).getmaxAR(); }

   double DB::getNodeAR(unsigned index) const
   {   return getNodeWidth(index) / getNodeHeight(index); }
   
   bool DB::isMacro(unsigned index) const
   {   return (_nodes->getNode(index)).isMacro(); }

   bool DB::isOrientFixed(unsigned index) const
   {   return (_nodes->getNode(index)).isOrientFixed(); }

   bool DB::isNodeSoft(unsigned index) const
   {   return getNodeMaxAR(index) - getNodeMinAR(index) > 1e-6; }

   bool DB::isNodeHard(unsigned index) const
   {   return !isNodeSoft(index); }
   // -----------------------------------------------------
   void DB::setNodeWidth(unsigned index, double width)
   {   (_nodes->getNode(index)).putWidth(width); }
   
   void DB::setNodeHeight(unsigned index, double height)
   {   (_nodes->getNode(index)).putHeight(height); }

   void DB::setNodeAR(unsigned index, double ar)
   {
      const double area = getNodeArea(index);
      setNodeWidth(index, sqrt(area * ar));
      setNodeHeight(index, sqrt(area / ar));
   }
   
   void DB::setXLoc(unsigned index, double newX)
   {   (_nodes->getNode(index)).putX(newX); }
   
   void DB::setYLoc(unsigned index, double newY)
   {   (_nodes->getNode(index)).putY(newY); }
   
   void DB::setOrient(unsigned index, ORIENT newOrient, bool ignoreNets)
   {
      if (ignoreNets)
         (_nodes->getNode(index)).putOrient(newOrient);
      else      
         _nodes->changeOrient(index, newOrient, *_nets);
   }
   
   void DB::setOrient(unsigned index, const char *newOrient, bool ignoreNets)
   {
      setOrient(index,
                toOrient(const_cast< char* >(newOrient)), ignoreNets);
   }
   // -----------------------------------------------------
   bool DB::updateNodeSlim(int index,
                           const Node& newNode)
   {
      if (index < int(_nodes->getNumNodes()))
      {
         Node& oldNode = _nodes->getNode(index);
         
         oldNode.putX(newNode.getX());
         oldNode.putY(newNode.getY());
         oldNode.changeOrient(newNode.getOrient(), *_nets);
         oldNode.putWidth(newNode.getWidth());
         oldNode.putHeight(newNode.getHeight());
         return true;
      }
      else
         return false;
   }
   // -----------------------------------------------------
   bool DB::updateNodeLocation(int index,
                               double xloc, double yloc)
   {
      if (index < int(_nodes->getNumNodes()))
      {
         Node& oldNode = _nodes->getNode(index);
         oldNode.putX(xloc);
         oldNode.putY(yloc);
         return true;
      }
      else
         return false;
   }
   // -----------------------------------------------------
   bool DB::updateNodeDimensions(int index,
                                 double width, double height)
   {
      if (index <int( _nodes->getNumNodes()))
      {
         Node& oldNode = _nodes->getNode(index);

         oldNode.putWidth(width);
         oldNode.putHeight(height);
         return true;
      }
      else
         return false;
   }
   // -----------------------------------------------------
   string DB::toString(DB::Corner corner)
   {
      switch (corner)
      {
      case BOTTOM_LEFT: return "bottom-left";
      case BOTTOM_RIGHT: return "bottom-right";
      case TOP_LEFT: return "top-left";
      case TOP_RIGHT: return "top-right";
      default: return "INVALID CORNER";
      }
   }
   // -----------------------------------------------------
}
// using namespace parquetfp;

#endif 
