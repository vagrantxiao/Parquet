/**************************************************************************
***    
*** Copyright (c) 1995-2000 Regents of the University of California,
***               Andrew E. Caldwell, Andrew B. Kahng and Igor L. Markov
*** Copyright (c) 2000-2004 Regents of the University of Michigan,
***               Saurabh N. Adya, Jarrod A. Roy and Igor L. Markov
***
***  Contact author(s): abk@cs.ucsd.edu, imarkov@umich.edu
***  Original Affiliation:   UCLA, Computer Science Department,
***                          Los Angeles, CA 90095-1596 USA
***
***  Permission is hereby granted, free of charge, to any person obtaining 
***  a copy of this software and associated documentation files (the
***  "Software"), to deal in the Software without restriction, including
***  without limitation 
***  the rights to use, copy, modify, merge, publish, distribute, sublicense, 
***  and/or sell copies of the Software, and to permit persons to whom the 
***  Software is furnished to do so, subject to the following conditions:
***
***  The above copyright notice and this permission notice shall be included
***  in all copies or substantial portions of the Software.
***
*** THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
*** EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
*** OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
*** IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
*** CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT
*** OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
*** THE USE OR OTHER DEALINGS IN THE SOFTWARE.
***
***
***************************************************************************/


#ifndef PLSPTOBTREE_H
#define PLSPTOBTREE_H

#include "btree.h"

#include <vector>
using namespace std;

// --------------------------------------------------------
class PlSP2BTree
{
public:
   PlSP2BTree(const vector<double>& n_xloc,
              const vector<double>& n_yloc,
              const vector<double>& n_widths,
              const vector<double>& n_heights,
              const vector<int>& XX,
              const vector<int>& YY);

   PlSP2BTree(const vector<double>& n_xloc,
              const vector<double>& n_yloc,
              const vector<double>& n_widths,
              const vector<double>& n_heights,
              const vector<unsigned int>& XX,
              const vector<unsigned int>& YY);

   inline const vector<BTree::BTreeNode>& btree() const;
   inline const vector<int>& SP_XX() const;
   inline const vector<int>& SP_YY() const;
   inline const vector<int>& SP_XXinverse() const;
   inline const vector<int>& SP_YYinverse() const;
   
   const vector<double>& xloc;
   const vector<double>& yloc;
   const vector<double>& widths;
   const vector<double>& heights;

   inline bool SPleftof(int i, int j) const;
   inline bool SPrightof(int i , int j) const;
   inline bool SPabove(int i, int j) const;
   inline bool SPbelow(int i, int j) const;

   static const double INFTY;
   static const int UNDEFINED; // = BTree::UNDEFINED;

private:
   int _blocknum;
   vector<int> _XX;
   vector<int> _YY;
   vector<int> _XXinverse;
   vector<int> _YYinverse;
   vector<BTree::BTreeNode> _btree;

   void constructor_core();
   void initializeTree();

   void build_tree();
   void build_tree_add_block(int currBlock, int otree_parent);
};
// --------------------------------------------------------

// ===============
// IMPLEMENTATIONS
// ===============
inline const vector<BTree::BTreeNode>& PlSP2BTree::btree() const
{   return _btree; }
// --------------------------------------------------------
inline const vector<int>& PlSP2BTree::SP_XX() const
{   return _XX; }
// --------------------------------------------------------
inline const vector<int>& PlSP2BTree::SP_YY() const
{   return _YY; }
// --------------------------------------------------------
inline const vector<int>& PlSP2BTree::SP_XXinverse() const
{   return _XXinverse; }
// --------------------------------------------------------
inline const vector<int>& PlSP2BTree::SP_YYinverse() const
{   return _YYinverse; }
// --------------------------------------------------------
inline bool PlSP2BTree::SPleftof(int i, int j) const
{   return (_XXinverse[i] < _XXinverse[j] &&
            _YYinverse[i] < _YYinverse[j]); }
// --------------------------------------------------------
inline bool PlSP2BTree::SPrightof(int i, int j) const
{   return SPleftof(j, i); }
// --------------------------------------------------------
inline bool PlSP2BTree::SPabove(int i, int j) const
{   return (_XXinverse[i] < _XXinverse[j] &&
            _YYinverse[i] > _YYinverse[j]); }
// --------------------------------------------------------
inline bool PlSP2BTree::SPbelow(int i, int j) const
{   return SPabove(j, i); }
// --------------------------------------------------------

#endif
