/**************************************************************************
***    
*** Copyright (c) 2000-2005 Regents of the University of Michigan,
***               Saurabh N. Adya, Matt Guthaus and Igor L. Markov
***
***  Contact author(s): sadya@umich.edu, imarkov@umich.edu
***  Original Affiliation:   University of Michigan, EECS Dept.
***                          Ann Arbor, MI 48109-2122 USA
***
***  Permission is hereby granted, free of charge, to any person obtaining 
***  a copy of this software and associated documentation files (the
***  "Software"), to deal in the Software without restriction, including
***  without limitation 
***  the rights to use, copy, modify, merge, publish, distribute, sublicense, 
***  and/or sell copies of the Software, and to permit persons to whom the 
***  Software is furnished to do so, subject to the following conditions:
***
***  The above copyright notice and this permission notice shall be included
***  in all copies or substantial portions of the Software.
***
*** THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
*** EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
*** OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
*** IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
*** CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT
*** OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
*** THE USE OR OTHER DEALINGS IN THE SOFTWARE.
***
***
***************************************************************************/


#ifndef SPEVAL_H
#define SPEVAL_H

#include <fstream>
#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <math.h>
#include <stdlib.h>
using namespace std;

namespace parquetfp
{
   class SPeval
   {
   private:
      //buffers go in here
      vector<unsigned> _match;
      vector<float> _LL;
      vector<unsigned> _reverseSeq;
      vector<unsigned> _XX;
      vector<unsigned> _YY;
      vector<float> _heights;
      vector<float> _widths;
      map<unsigned , float> _BST;  //for the O(nlogn) algo
      vector<unsigned> _reverseSeq2; //only for O(nlog n) algo

      vector< vector<bool> > _TCGMatrixHoriz;
      vector< vector<bool> > _TCGMatrixVert;

      float _lcsCompute(const vector<unsigned>& X,
                         const vector<unsigned>& Y,
                         const vector<float>& weights,
                         vector<unsigned>& match,
                         vector<float>& P,
                         vector<float>& L
         );

      float _lcsReverseCompute(const vector<unsigned>& X,
                                const vector<unsigned>& Y,
                                const vector<float>& weights,
                                vector<unsigned>& match,
                                vector<float>& P,
                                vector<float>& L
         );
  
      float _lcsComputeCompact(const vector<unsigned>& X,
                                const vector<unsigned>& Y,
                                const vector<float>& weights,
                                vector<unsigned>& match,
                                vector<float>& P,
                                vector<float>& L,
                                vector<float>& oppLocs,
                                vector<float>& oppWeights
         );
  
      //fast are for the O(nlog n) algo
      float _findBST(unsigned index); //see the paper for definitions
      void _discardNodesBST(unsigned index, float length);

      float _lcsComputeFast(const vector<unsigned>& X,
                             const vector<unsigned>& Y,
                             const vector<float>& weights,
                             vector<unsigned>& match,
                             vector<float>& P,
                             vector<float>& L
         );


      bool _TCGMatrixInitialized;
      void _initializeTCGMatrix(unsigned size);
      bool _paramUseFastSP;

   public:
      vector<float> xloc;
      vector<float> yloc;
      float xSize;
      float ySize;
      vector<float> xSlacks;
      vector<float> ySlacks;
      vector<float> xlocRev;
      vector<float> ylocRev;


      SPeval(const vector<float>& heights,
             const vector<float>& widths,
             bool paramUseFastSP);

  
      void evaluate(const vector<unsigned>& X, const vector<unsigned>& Y,
                    bool leftpack, bool botpack);
      float xEval(bool leftpack, vector<float>& xcoords);
      float yEval(bool botpack,  vector<float>& ycoords);
      void evalSlacks(const vector<unsigned>& X, const vector<unsigned>& Y,
                      bool leftpack, bool botpack);
      void evaluateCompact(const vector<unsigned>& X,
                           const vector<unsigned>& Y, 
                           bool whichDir, bool leftpack, bool botpack);
      float xEvalCompact(bool leftpack, vector<float>& xcoords, vector<float>& ycoords);
      float yEvalCompact(bool botpack,  vector<float>& xcoords, vector<float>& ycoords);
      void computeConstraintGraphs();
      void removeRedundantConstraints(bool knownDir);
      void computeSPFromCG();

      //following are for evaluating with the O(nlog n) scheme
      void evaluateFast(const vector<unsigned>& X, const vector<unsigned>& Y,
                        bool leftpack, bool botpack);
      float xEvalFast(bool leftpack, vector<float>& xcoords);
      float yEvalFast(bool botpack,  vector<float>& ycoords);
      void evalSlacksFast(const vector<unsigned>& X, const vector<unsigned>& Y,
                          bool leftpack, bool botpack);

      //miscelleneous functions
      void changeWidths(const vector<float>& widths);
      void changeHeights(const vector<float>& heights);
      void changeNodeWidth(const unsigned index, float width);
      void changeNodeHeight(const unsigned index, float height);
      void changeOrient(unsigned index);
   };
}
//using namespace parquetfp;

#endif
