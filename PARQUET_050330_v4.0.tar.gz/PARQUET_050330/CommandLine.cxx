/**************************************************************************
***    
*** Copyright (c) 2000-2005 Regents of the University of Michigan,
***               Saurabh N. Adya, Matt Guthaus and Igor L. Markov
***
***  Contact author(s): sadya@umich.edu, imarkov@umich.edu
***  Original Affiliation:   University of Michigan, EECS Dept.
***                          Ann Arbor, MI 48109-2122 USA
***
***  Permission is hereby granted, free of charge, to any person obtaining 
***  a copy of this software and associated documentation files (the
***  "Software"), to deal in the Software without restriction, including
***  without limitation 
***  the rights to use, copy, modify, merge, publish, distribute, sublicense, 
***  and/or sell copies of the Software, and to permit persons to whom the 
***  Software is furnished to do so, subject to the following conditions:
***
***  The above copyright notice and this permission notice shall be included
***  in all copies or substantial portions of the Software.
***
*** THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
*** EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
*** OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
*** IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
*** CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT
*** OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
*** THE USE OR OTHER DEALINGS IN THE SOFTWARE.
***
***
***************************************************************************/


// 040608 hhchan param printout up to v2.1 are placed in the "classic" fcn

#include "CommandLine.h"
#include "ABKCommon/abkcommon.h"
#include "ABKCommon/verbosity.h"

#include "baseannealer.h" 

#include <iostream>
#include <string.h>
#include <time.h>
using namespace std;
using namespace parquetfp;

#ifdef _MSC_VER
#ifndef srand48
#define srand48 srand
#endif
#endif

Command_Line::Command_Line ()
   : getSeed(false),
     budgetTime(0), softBlocks(0), initQP(0), FPrep("SeqPair"),
     seed(0), iterations(1), 
     maxIterHier(10),
     seconds(0.0f), plot(0), savePl(0), saveCapoPl(0), saveCapo(0), 
     save(0), takePl(0), solveMulti(0), clusterPhysical(0), 
     solveTop(0), maxWSHier(15), usePhyLocHier(0),
     dontClusterMacros(0), maxTopLevelNodes(-9999),
     timeInit(30000.0f), timeCool(0.01f), 
     startTime(30000.0f), reqdAR(-9999.0f), maxWS(15.0f), minWL(0), 
     areaWeight(0.4f), wireWeight(0.4f),
     useFastSP(false), snapToGrid(false), initCompact(0), compact(0), 
     verb("1 1 1"), packleft(true), packbot(true)
{
   setSeed();
   inFileName[0] = '\0';
   outPlFile[0] = '\0';
   capoPlFile[0] = '\0';
   capoBaseFile[0] = '\0';
   baseFile[0] = '\0';
}

Command_Line::Command_Line (int argc, const char *argv[])
   : getSeed(0),
     budgetTime(0), softBlocks(0), initQP(0), FPrep("SeqPair"),
     seed(0), iterations(0), 
     maxIterHier(10),
     seconds(0.0f), plot(0), savePl(0), saveCapoPl(0), saveCapo(0), 
     save(0), takePl(0), solveMulti(0), clusterPhysical(0), 
     solveTop(0), maxWSHier(15), usePhyLocHier(0),
     dontClusterMacros(0), maxTopLevelNodes(-9999), 
     timeInit(30000.0f), timeCool(0.01f), 
     reqdAR(-9999.0f), maxWS(15.0f), minWL(0), areaWeight(0.4f), 
     wireWeight(0.4f), useFastSP(false), 
     snapToGrid(false), initCompact(0), compact(0),
     verb(argc,argv), packleft(true), packbot(true)
{
   inFileName[0] = '\0';
   outPlFile[0] = '\0';
   capoPlFile[0] = '\0';
   capoBaseFile[0] = '\0';
   baseFile[0] = '\0';
   StringParam argInfile ("f", argc, argv);
   StringParam plOutFile ("savePl", argc, argv);
   StringParam saveCapoPlFile ("saveCapoPl", argc, argv);
   StringParam saveCapoFile ("saveCapo", argc, argv);
   StringParam saveFile ("save", argc, argv);

   StringParam FPrep_("FPrep", argc, argv);

   BoolParam help1 ("h", argc, argv);
   BoolParam help2 ("help", argc, argv);
   NoParams  noParams(argc,argv);  // this acts as a flag
   IntParam  fixSeed ("s",argc,argv);
   IntParam  numberOfRuns("n",argc,argv);	
   DoubleParam timeReq("t",argc,argv);
   IntParam  maxIterHier_("maxIterHier",argc,argv);	

   DoubleParam timeInit_("timeInit",argc,argv);
   DoubleParam timeCool_("timeCool",argc,argv);
   DoubleParam startTime_("startTime",argc,argv);
   DoubleParam reqdAR_("AR",argc,argv);
   DoubleParam maxWS_("maxWS",argc,argv);
   BoolParam   minWL_("minWL",argc,argv);
   DoubleParam wireWeight_("wireWeight",argc,argv);
   DoubleParam areaWeight_("areaWeight",argc,argv);
   BoolParam softBlocks_("soft", argc, argv);
   BoolParam initQP_("initQP", argc, argv);
   BoolParam fastSP_("fastSP", argc, argv);

   BoolParam plot_("plot",argc,argv);
   BoolParam plotNoNets_("plotNoNets", argc, argv);
   BoolParam plotNoSlacks_("plotNoSlacks", argc, argv);
   BoolParam plotNoNames_("plotNoNames",argc,argv);
   BoolParam takePl_("takePl",argc,argv);
   BoolParam solveMulti_("solveMulti",argc,argv);
   BoolParam clusterPhysical_("clusterPhysical",argc,argv);
   BoolParam solveTop_("solveTop",argc,argv);
   DoubleParam maxWSHier_("maxWSHier",argc,argv);
   BoolParam usePhyLocHier_("usePhyLocHier",argc,argv);
   BoolParam dontClusterMacros_("dontClusterMacros",argc,argv);
   IntParam maxTopLevelNodes_("maxTopLevelNodes",argc,argv);
   BoolParam compact_("compact",argc,argv);
   BoolParam initCompact_("initCompact", argc, argv);
   BoolParam snapToGrid_("snapToGrid", argc, argv);

   // now set up member vars
   if (argInfile.found())
   {
      string temp;
      temp=argInfile;
      strcpy(inFileName,temp.c_str());
   }
   else
   {
      strcpy(inFileName,"TESTS/ami49");
   }

   if(plOutFile.found())
   {
      strcpy(outPlFile, plOutFile);
      savePl = true;
   }

   if(saveCapoPlFile.found())
   {
      strcpy(capoPlFile, saveCapoPlFile);
      saveCapoPl = true;
   }

   if(saveCapoFile.found())
   {
      strcpy(capoBaseFile, saveCapoFile);
      saveCapo = true;
   }

   if(saveFile.found())
   {
      strcpy(baseFile, saveFile);
      save = true;
   }

   if (FPrep_.found())
   {
      FPrep = FPrep_;
   }
		
   if (fixSeed.found())
   {
      getSeed = false;
      seed = fixSeed;
   }
   else
      getSeed = true;//get sys time as seed

   if (numberOfRuns.found())
      iterations = numberOfRuns;
   else
      iterations = 1;
	
   if (maxIterHier_.found())
      maxIterHier = maxIterHier_;

   if (timeReq.found())
   {
      budgetTime=true;//limit number of runs
      seconds = timeReq;
   }
   else
      budgetTime=false;

	  
   if(timeInit_.found())
      timeInit = timeInit_;

   if(startTime_.found())
      startTime = startTime_;
   else
      startTime = timeInit;

	  
   if(timeCool_.found())
      timeCool = timeCool_;
	  
   if(reqdAR_.found())
      reqdAR = reqdAR_;   //default -9999 means no fixed outline desired
	
   if(maxWS_.found())
      maxWS = maxWS_;

   if(maxWSHier_.found())
      maxWSHier = maxWSHier_;

   if(usePhyLocHier_.found())
      usePhyLocHier = 1;

   if(maxTopLevelNodes_.found())
      maxTopLevelNodes = maxTopLevelNodes_;

   if(minWL_.found())
   {
      minWL = 1;
   }

   if(areaWeight_.found())
   {
      areaWeight = areaWeight_;
      if(areaWeight > 1 || areaWeight < 0)
      {
         cout<<"areaWeight should be : 0 <= areaWeight <= 1"<<endl;  
         exit(0);
      }
   }

   if(wireWeight_.found())
   {
      wireWeight = wireWeight_;
      if(wireWeight > 1 || wireWeight < 0)
      {
         cout<<"wireWeight should be : 0 <= wireWeight <= 1"<<endl;  
         exit(0);
      }

      if(wireWeight == 0) //turn off minWL if wireWeight is 0
         minWL = false;
   }

   if(takePl_.found())
      takePl = 1;

   if(solveMulti_.found())
      solveMulti = 1;

   if(clusterPhysical_.found())
      clusterPhysical = 1;

   if(solveTop_.found())
      solveTop = 1;

   if(dontClusterMacros_.found())
      dontClusterMacros = 1;

   if(softBlocks_.found())
      softBlocks = 1;
	  
   if(initQP_.found())
      initQP = 1;

   if(fastSP_.found())
      useFastSP = 1;

   if(compact_.found())
      compact = 1;

   if(initCompact_.found())
      initCompact = 1;

   if(snapToGrid_.found())
      snapToGrid = 1;
 
   if(plot_.found() || plotNoNets_.found() || plotNoSlacks_.found() ||
      plotNoNames_.found())
      plot = 1;
	
   plotNoNets = plotNoNets_;
   plotNoSlacks = plotNoSlacks_;
   plotNoNames = plotNoNames_;

   setSeed();
}

void Command_Line::printHelp(int argc, const char *argv[]) const
{
   cerr<< argv[0] << endl 
       <<"-f filename\n"
       <<"-s int        (give a fixed seed)\n"
       <<"-n int        (determine number of runs. default 1)\n"
       <<"-t float     (set a time limit on the annealing run)\n"
       <<"-FPrep {SeqPair | BTree} (floorplan representation default: SeqPair)\n"
       <<"-save basefilename       (save design in bookshelf format)\n"
       <<"-savePl baseFilename     (save .pl file of solution)\n"
       <<"-saveCapoPl basefilename (save .pl in Capo format)\n"
       <<"-saveCapo basefilename   (save design in Capo format)\n"
       <<"-plot         (plot the output solution to out.plt file)\n"
       <<"-plotNoNets   (plot without the nets)\n"
       <<"-plotNoSlacks (plot without slacks info)\n"
       <<"-plotNoNames  (plot without name of blocks)\n"
       <<"-timeInit float  (initial normalizing time: default 30000)\n"
       <<"-startTime float (annealing initial time: default timeInit)\n"
       <<"-timeCool float  (annealing cool time: default 0.01\n"
       <<"-AR float  (required Aspect Ratio of fixed outline: default no Fixed Outline)\n"
       <<"-maxWS float (maxWS(%) allowed if fixed outline constraints)\n"
       <<"-maxWSHier float (maxWS(%) for each hierarchical block)\n"
       <<"-usePhyLocHier (use physical locs which updating locs of sub-blocks of clustered blocks)\n"
       <<"-maxTopLevelNodes int (max # top level nodes during clustering)\n"
       <<"-maxIterHier int (max # of iterations in hierarchical mode to satisfy fixed-outline)\n"
       <<"-minWL        (minimize WL default turned off)\n"
       <<"-wireWeight float  (default 0.4)\n"
       <<"-areaWeight float  (default 0.4)\n"
       <<"-soft         (soft Blocks present in input default no)\n"
       <<"-initQP       (start the annealing with a QP solution)\n"
       <<"-fastSP       (use O(nlog n) algo for sequence pair evaluation)\n"
       <<"-takePl       (take a placement and convert to sequence pair for use as initial solution)\n"
       <<"-solveMulti   (solve as multiLevel heirarchy)\n"
       <<"-clusterPhysical (use Physical Heirarchy)\n"
       <<"-dontClusterMacros (keep Macros out of Clustering)\n"
       <<"-solveTop     (solve only top level of heirarchy)\n"
       <<"-compact      (compact the final solution)\n"
       <<"-initCompact  (construct initial SP by compaction)\n"
       <<"-snapToGrid   (snap to row and site grid)\n"
       <<endl;
}

void Command_Line::printAnnealerParams() const
{
   cout << "Annealer Parameters: " << endl;
   cout << "   normalizing Time:  " << timeInit << endl;
   cout << "   start Time:        " << startTime << endl;
   cout << "   cooling Time:      " << timeCool << endl;
   cout << "   fixed-outline?     "
        << ((reqdAR != BaseAnnealer::FREE_OUTLINE)? "Yes" : "No") << endl;

   if (reqdAR != BaseAnnealer::FREE_OUTLINE)
   {
      cout << "    -reqd Aspect Ratio:  " << reqdAR << endl;
      cout << "    -maximum WS:         " << maxWS << "%" << endl;
   }      
      
   cout << "   minimize WL?       " << ((minWL)? "Yes" : "No") << endl;;
   if (minWL)
   {
      cout << "    -wireWeight =  " << wireWeight << endl;
      cout << "    -areaWeight =  " << areaWeight << endl;
   }

   cout << "   soft blks exist?        " << ((softBlocks)? "Yes" : "No") << endl;
   cout << "   use initial placement?  " << ((takePl)? "Yes" : "No") << endl;
   cout << "   compact init plmt?      " << ((initCompact)? "Yes" : "No") << endl;
   cout << "   compact final plmt?     " << ((compact)? "Yes" : "No") << endl;
   cout << "   use quad-pl as initial? " << ((initQP)? "Yes" : "No") << endl;
   cout << endl;
}

void Command_Line::printAnnealerParamsClassic() const
{
   cout << "Annealer Params: "<<endl;
   cout << "\tnormalizing Time  " << timeInit << endl;
   cout << "\tstart Time        " << startTime << endl;
   cout << "\tcooling Time      " << timeCool << endl;
   cout<<"\treqd Aspect Ratio "<<reqdAR<<" (-9999 means no fixed shape)"<<endl;
   cout<<"\tminimize WL       "<<minWL;
   if(minWL == 1)
      cout<<"   :  wireWeight = "<<wireWeight;
   cout<<endl;
   cout<<"\tmaximum WS        "<<maxWS<<"% (only for fixed-outline)"<<endl<<endl;
}

void Command_Line::setSeed()
{
   int rseed;
   if(getSeed)
      rseed = int(time((time_t *)NULL));
   else
      rseed = seed;
  
   srand(rseed);        //seed for rand function
   srand48(rseed);      //seed for random_shuffle function
//   if(verb.forMajStats > 0)
//      cout<<"The random seed for this run is: "<<rseed<<endl;
}

