/**************************************************************************
***    
*** Copyright (c) 1995-2000 Regents of the University of California,
***               Andrew E. Caldwell, Andrew B. Kahng and Igor L. Markov
*** Copyright (c) 2000-2005 Regents of the University of Michigan,
***               Saurabh N. Adya, Jarrod A. Roy, David A. Papa and
***               Igor L. Markov
***
***  Contact author(s): abk@cs.ucsd.edu, imarkov@umich.edu
***  Original Affiliation:   UCLA, Computer Science Department,
***                          Los Angeles, CA 90095-1596 USA
***
***  Permission is hereby granted, free of charge, to any person obtaining 
***  a copy of this software and associated documentation files (the
***  "Software"), to deal in the Software without restriction, including
***  without limitation 
***  the rights to use, copy, modify, merge, publish, distribute, sublicense, 
***  and/or sell copies of the Software, and to permit persons to whom the 
***  Software is furnished to do so, subject to the following conditions:
***
***  The above copyright notice and this permission notice shall be included
***  in all copies or substantial portions of the Software.
***
*** THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
*** EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
*** OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
*** IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
*** CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT
*** OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
*** THE USE OR OTHER DEALINGS IN THE SOFTWARE.
***
***
***************************************************************************/













#ifndef GCC_VERSION
#define GCC_VERSION (__GNUC__ * 10000 \
	+ __GNUC_MINOR__ * 100 \
	+ __GNUC_PATCHLEVEL__)
#endif

#include "ABKCommon/sgi_stl_compat.h"

#ifndef _SGI_HASHMAP_H
 #define _SGI_HASHMAP_H
 #ifdef __GNUC__
    #if( __GNUC__ >= 3)
      #include <ext/hash_map>
      #include <string>
      #if(GCC_VERSION >= 30100)
        using __gnu_cxx::hash_map;
        using __gnu_cxx::hash;
        namespace __gnu_cxx 
        {
           template<> struct hash< std::string > 
           {
             size_t operator()( const std::string& x ) const
             {
                return hash< const char* >()( x.c_str() );
             }
           };
        }
      #else  
        using std::hash_map;
        using std::hash;
      #endif
   #else
    #include <hash_map>
    #include <string>
    template<> struct hash< std::string > 
           {
             size_t operator()( const std::string& x ) const
             {
                return hash< const char* >()( x.c_str() );
             }
           };
   #endif
 #else
   #ifdef _MSC_VER
     #include<hash_map>
     #ifndef _ONEHASH
     #define _ONEHASH
		template<class T> class hash : public std::hash_compare<T> {};
     #endif
	  template<class A, class B, class C,class D> class hash_map : public std::hash_map<A,B,C> {};
   #else
     #include "ABKCommon/SGI_STL_COMPAT/hash_map.h" 
   #endif
 #endif
#endif


#include <functional>
using std::equal_to;
