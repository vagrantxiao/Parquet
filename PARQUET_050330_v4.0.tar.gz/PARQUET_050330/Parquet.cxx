/**************************************************************************
***    
*** Copyright (c) 2000-2005 Regents of the University of Michigan,
***               Saurabh N. Adya, Matt Guthaus and Igor L. Markov
***
***  Contact author(s): sadya@umich.edu, imarkov@umich.edu
***  Original Affiliation:   University of Michigan, EECS Dept.
***                          Ann Arbor, MI 48109-2122 USA
***
***  Permission is hereby granted, free of charge, to any person obtaining 
***  a copy of this software and associated documentation files (the
***  "Software"), to deal in the Software without restriction, including
***  without limitation 
***  the rights to use, copy, modify, merge, publish, distribute, sublicense, 
***  and/or sell copies of the Software, and to permit persons to whom the 
***  Software is furnished to do so, subject to the following conditions:
***
***  The above copyright notice and this permission notice shall be included
***  in all copies or substantial portions of the Software.
***
*** THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
*** EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
*** OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
*** IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
*** CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT
*** OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
*** THE USE OR OTHER DEALINGS IN THE SOFTWARE.
***
***
***************************************************************************/
// 040607 hhchan added btree annealer stuff
// 040608 hhchan wrapped everything to class Parquet
// 040608 hhchan put all pre/post-processing out of the annealers

#include "Parquet.h"
#include "ABKCommon/abkcommon.h"

#include "mixedpacking.h"
#include "baseannealer.h"
#include "btreeanneal.h"

#include <iostream>
#include <iomanip>
#include <cfloat>
#include <algorithm>
using namespace std;
using namespace parquetfp; 

// --------------------------------------------------------
int main(int argc, char *argv[])
{
   Parquet engine(argc, const_cast<const char**>(argv));
   return engine.go();
}
// --------------------------------------------------------
Parquet::Parquet(int argc,
                 const char *argv[])
   : params(argc, argv)
{
   BoolParam help1 ("h", argc, argv);
   BoolParam help2 ("help", argc, argv);
   NoParams  noParams(argc,argv);  // this acts as a flag
   params.printAnnealerParams();
   
   if (noParams.found() || help1.found() || help2.found())
   {
      params.printHelp(argc, argv);
      exit (0);
   }	
}
// --------------------------------------------------------
int Parquet::go()
{
   Timer T;
   T.stop();
   
   float totalTime = 0;
   float successTime = 0;
   float successAvgWL = 0;
   float successAvgWLnoWts = 0;
   float successAvgArea = 0;
   float successMinWL = FLT_MAX;
   float successMinWLnoWts = FLT_MAX;
   float successMinArea = FLT_MAX;
   float successMaxWL = 0;
   float successMaxWLnoWts = 0;
   float successMaxArea = 0;
   float successAR = 0;

   float minArea = FLT_MAX;
   float minWS = FLT_MAX;
   float minWL = FLT_MAX;
   float minWLnoWts = FLT_MAX;

   float aveArea = 0;
   float aveWS = 0;
   float aveWL = 0;
   float aveWLnoWts = 0;

   float maxArea = 0;
   float maxWS = 0;
   float maxWL = 0;
   float maxWLnoWts = 0;

   float currArea = FLT_MAX;
   float currWS = FLT_MAX;
   float currWL = FLT_MAX;
   float currXSize = FLT_MAX;
   float currYSize = FLT_MAX;
   float currWLnoWts = FLT_MAX;


   for (int i = 0; i < params.iterations; i++)
   {
      cout << endl << "***** START: round " << (i+1) << " / "
           << params.iterations << " *****" << endl;
      
      string blocksname(params.inFileName);
      blocksname += ".blocks";
      MixedBlockInfoType blockinfo(blocksname, "blocks");
      DB db(const_cast<char*>(params.inFileName));
      //DB db(db2,true);

      float blocksArea = db.getNodesArea();
      const float reqdArea = blocksArea * (1 + (params.maxWS/100.0));
      const float reqdWidth = sqrt(reqdArea * params.reqdAR);
      const float reqdHeight = reqdWidth / params.reqdAR;
      bool gotBetterSol = false;

      T.start(0.0);
         
      if (!params.solveMulti)
      {
         BaseAnnealer *annealer = NULL;
         if (params.FPrep == "BTree")
         {
            annealer =
               new BTreeAreaWireAnnealer(blockinfo,
                                         const_cast<Command_Line*>(&params),
                                         &db);
         }
         else if (params.FPrep == "SeqPair")
         {
            annealer = new Annealer(&params, &db);
         }
         else
         {
            abkfatal(false, "Invalid floorplan representation specified");
            exit(1);
         }

         // normal flat annealing
         if (params.takePl)
         {
            cout << endl;
            cout << "----- Converting placement to initial solution -----"
                 << endl;
            annealer->takePlfromDB();
            cout << "----- done converting -----" << endl;
         } 

         if (params.initQP)
         {
            cout << endl;
            cout << "----- Computing quadratic-minimum WL solution -----"
                 << endl;
            annealer->BaseAnnealer::solveQP();
            cout << "----- done computing -----" << endl;

            cout << "----- Converting placement to initial solution -----"
                 << endl;
            annealer->takePlfromDB();
            cout << "----- done converting -----" << endl;
         }
	       
         if (params.initCompact)
         {
            // compact the curr solution
            cout << endl;
            cout << "----- Compacting initial solution -----"
                 << endl;
            annealer->compactSoln();
            cout << "----- done compacting -----" << endl;
         }

         cout << endl;
         cout << "----- Annealing with " << params.FPrep
              << " -----" << endl;
         annealer->go();
         cout << "----- Annealing with " << params.FPrep
              << " -----" << endl;

         if(params.compact)
         {
            // compact the design
            cout << endl;
            cout << "----- Compacting the final solution -----"
                 << endl;
            annealer->compactSoln();
            cout << "----- done compacting -----" << endl;
         }

         if (params.minWL &&
             params.reqdAR != BaseAnnealer::FREE_OUTLINE)
         {
            // shift design, only in fixed-outline mode
            cout << endl;
            cout << "----- Try Shifting the design for better HPWL -----"
                 << endl;
            annealer->postHPWLOpt();
            cout << "----- done trying -----" << endl;
         }

            
         
         delete annealer;
      }
      else 
      {
         // two-level annealing
         SolveMulti solveMulti(const_cast<DB*>(&db),
                               const_cast<Command_Line*>(&params));
         solveMulti.go();
	       
         if (params.compact)
         {
            // compact the design            
            Annealer annealer(&params, &db);
            annealer.takePlfromDB();
            annealer.compactSoln();
         }
      }

      db.cornerOptimizeDesign();         
      T.stop();

      // ----- statistics -----
      totalTime += T.getUserTime();
      currXSize = db.getXSize();
      currYSize = db.getYSize();
      
      currArea = currXSize * currYSize;
      currWS = 100*(currArea - blocksArea)/blocksArea;
      currWL = db.evalHPWL();
      currWLnoWts = db.evalHPWL(false);

      gotBetterSol = false;
      if (params.reqdAR != BaseAnnealer::FREE_OUTLINE)
      {
         gotBetterSol = (currXSize <= reqdWidth && currYSize <= reqdHeight);

         if (params.minWL)
            gotBetterSol = gotBetterSol && (currWL < successMinWL);
         else
            gotBetterSol = gotBetterSol && (currArea < successMinArea);
      }
      else if (params.minWL)
         gotBetterSol = (currWL < minWL);
      else
         gotBetterSol = (currArea < minArea);

      aveArea += currArea;
      aveWS += currWS;
      aveWL += currWL;
      aveWLnoWts += currWLnoWts;

      minArea = min(minArea, currArea);
      minWS = min(minWS, currWS);
      minWL = min(minWL, currWL);
      minWLnoWts = min(minWLnoWts, currWLnoWts);

      maxArea = max(maxArea, currArea);
      maxWS = max(maxWS, currWS);
      maxWL = max(maxWL, currWL);
      maxWLnoWts = max(maxWLnoWts, currWLnoWts);

         
      if(params.reqdAR != BaseAnnealer::FREE_OUTLINE &&
         ((currArea <= reqdArea && 
           currXSize <= reqdWidth &&
           currYSize <= reqdHeight) || db.successAR))
      {
         ++successAR;
         successTime += T.getUserTime();
         
         successAvgWL += currWL;
         successAvgArea += currArea;
         successAvgWLnoWts += currWLnoWts;

         successMinWL = min(successMinWL, currWL);
         successMinArea = min(successMinArea, currArea);
         successMinWLnoWts = min(successMinWLnoWts, currWLnoWts);

         successMaxWL = max(successMaxWL, currWL);
         successMaxArea = max(successMaxArea, currArea);
         successMaxWLnoWts = max(successMaxWLnoWts, currWLnoWts);
      }
      
      // plot and save the best solution
      if(gotBetterSol)
      {
         if(params.plot)
         {
            float currAR = currXSize/currYSize;
            bool plotSlacks = !params.plotNoSlacks;
            bool plotNets = !params.plotNoNets;
            bool plotNames = !params.plotNoNames;
            db.plot("out.plt", currArea, currWS, currAR, T.getUserTime(), 
                    currWL, plotSlacks, plotNets, plotNames);
         }
         
         if(params.savePl)
            db.getNodes()->savePl(const_cast<char*>(params.outPlFile));

         if(params.saveCapoPl)
            db.getNodes()->saveCapoPl(const_cast<char*>(params.capoPlFile));

         if(params.saveCapo)
            db.saveCapo(const_cast<char*>(params.capoBaseFile),
                        params.reqdAR);

         if(params.save)
            db.save(const_cast<char*>(params.baseFile));
	      
         //if(db.successAR)
         //db.saveBestCopyPl("best.pl");
      }

      BaseAnnealer::SolutionInfo curr;
      curr.area = currArea;
      curr.width = currXSize;
      curr.height = currYSize;
      curr.HPWL = currWL;

      //cout << endl << "Overall statistics: " << endl;
      //annealer->printResults(T, curr);
         
      cout << "***** DONE:  round " << (i+1) << " / "
           << params.iterations << " *****" << endl;

   } // end the for-loop
   
   aveArea /= params.iterations;
   aveWS /= params.iterations;
   aveWL /= params.iterations;
   aveWLnoWts /= params.iterations;
   totalTime /= params.iterations;
   successTime /= successAR;
   successAvgWL /= successAR;
   successAvgWLnoWts /= successAR;
   successAvgArea /= successAR;
   successAR /= params.iterations;
	
   cout << endl;
   cout << "***** SUMMARY of all rounds *****" << endl;
   cout << setw(15) << "Area: " << "Min: " << minArea << " Average: "
        << aveArea << " Max: " << maxArea << endl;
   cout << setw(15) << "HPWL: "<< "Min: " << minWL << " Average: "
        << aveWL << " Max: " << maxWL << endl;
   cout << setw(15) << "Unweighted HPWL: "<< "Min: " <<minWLnoWts<<" Average: "
        << aveWLnoWts << " Max: " << maxWLnoWts << endl;
   cout << setw(15) << "WhiteSpace: " << "Min: " << minWS << "% Average: "
        << aveWS << "%" << " Max: " << maxWS << "%" << endl;
   cout << "Average Time: " << totalTime << endl;
   
   if (params.reqdAR != BaseAnnealer::FREE_OUTLINE)
   {
      cout << endl;
      cout << "Success Rate of satisfying fixed outline: "
           << (100*successAR) << " %" << endl;

      if (successAR > 0)
      {
         cout << setw(15) << "Area: " << "Min: " << successMinArea 
              << " Average: "
              << successAvgArea << " Max: " << successMaxArea << endl;
         cout << setw(15) << "HPWL: "<< "Min: " << successMinWL << " Average: "
              << successAvgWL << " Max: " << successMaxWL << endl;
         cout << setw(15) << "Unweighted HPWL: "<< "Min: " << successMinWLnoWts
              << " Average: "<< successAvgWLnoWts << " Max: " 
              << successMaxWLnoWts << endl;
         cout << "Average Time: " << successTime << endl;
      }
   }
   return 0;
}
