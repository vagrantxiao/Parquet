#include <vector>
#include <algorithm>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "Net.h"

class Nodes;
typedef std::vector<Net>::iterator itNet;

class Nets
{
 private:
  vector<Net> _nets;
  
 public:
  Nets(char* baseName);

  void parseNets(char* fnameNets);

  void updateNodeInfo(Nodes& nodes);

  itNet netsBegin(void)
    { return _nets.begin(); }

  itNet netsEnd(void)
    { return _nets.end(); }

  Net& getNet(unsigned index)
    { return _nets[index]; }

  int getNumPins(void);

  unsigned getNumNets(void)
    { return _nets.size(); }
};
