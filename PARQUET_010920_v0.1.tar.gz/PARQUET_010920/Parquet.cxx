#include "FPcommon.h"
#include "Annealer.h"
#include "command_line.h"
#include "UTIL/infolines.h"

int main(int argc, const char *argv[])
{
        Timer T;
	T.stop();
	double totalTime=0;
	double successTime = 0;
	double minArea=1e100;
	double minWS=1e100;
	double minWL=1e100;
	double aveArea=0;
	double aveWS=0;
	double aveWL=0;
	double currArea;
	double currWS;
	double currWL;
	double currXSize;
	double currYSize;
	double successAR=0;
	
	Command_Line* params = new Command_Line(argc, argv);
	
	for (int i=0; i<params->iterations; i++)
	{
	   DB* db = new DB(params->inFileName);
	   double blocksArea = db->getNodesArea();
	   double reqdArea = blocksArea*1.15;
	   double reqdWidth = sqrt(reqdArea*params->reqdAR);
	   double reqdHeight = reqdWidth/params->reqdAR;
	   //reqdWidth *= 1.1;
	   //reqdHeight *= 1.1;
	   
	   Annealer annealer(params, db);
	   if(params->initQP)
	    {
              annealer.solveQP();
	      annealer.takeSPfromDB();
	    }
	   T.start(0.0);
	   annealer.go();
	   T.stop();
	   totalTime += T.getUserTime();
	   currXSize = annealer.getXSize();
	   currYSize = annealer.getYSize();
	   currArea = currXSize*currYSize;
	   currWS = 100*(currArea - blocksArea)/currArea;
	   currWL = db->evalHPWL();
	   aveArea += currArea;
	   aveWS += currWS;
	   aveWL += currWL;
	   if(minArea > currArea)
	     minArea = currArea;
	   if(minWS > currWS)
	     minWS = currWS;
	   if(minWL > currWL)
	     minWL = currWL;

	   if(params->reqdAR != -9999 && currArea<=reqdArea && 
	      currXSize<=reqdWidth && currYSize<=reqdHeight)
	      {
	        ++successAR;
		successTime += T.getUserTime();
	      }
	   //plot the last solution of the iteration
	   if(i == (params->iterations-1))
	    {
	      if(params->plot)
	      {
	        double currAR = annealer.getXSize()/annealer.getYSize();
                bool plotSlacks = !params->plotNoSlacks;
                bool plotNets = !params->plotNoNets;
	        bool plotNames = !params->plotNoNames;
                db->plot("out.gpl", currArea, currWS, currAR, T.getUserTime(), 
	      	  	  currWL, plotSlacks, plotNets, plotNames);
	      }
	      if(params->savePl)
	        db->getNodes()->savePl(params->outPlFile);

	      if(params->saveCapo)
	        db->saveCapo(params->capoBaseFile, params->reqdAR);
	    }
	}
        aveArea /= params->iterations;
	aveWS /= params->iterations;
	aveWL /= params->iterations;
        totalTime /= params->iterations;
	successTime /= successAR;
	successAR /= params->iterations;
	
	cout<<"Average Area: "<<aveArea<<" Minimum Area: "<<minArea<<endl
	    <<"Average HPWL: "<<aveWL<<" Minimum HPWL: "<<minWL<<endl
	    <<"Average WhiteSpace: "<<aveWS<<"%"<<" Minimum WhiteSpace: "<<minWS<<"%"<<endl
	    <<"Average Time: "<<totalTime<<endl;
	if(params->reqdAR != -9999)
	 {
	  cout<<"Success Rate of satisfying fixed outline: "<<100*successAR
	      <<" %"<<endl;
	  cout<<"Average Time for successfull AR runs: "<<successTime<<endl;
	 }
	return 0;
}
