#include <fstream.h>
#include <vector>
#include <algorithm>
#include <math.h>
#include <stdlib.h>


class SeqPair
{
 private:
  vector<unsigned> _X;         //seqPair in the X direction
  vector<unsigned> _Y;         //seqPair in the Y direction

 public:
  SeqPair(){}
  SeqPair(unsigned size);
  SeqPair(vector<unsigned>& X, vector<unsigned>& Y);

  vector<unsigned>& getX();
  vector<unsigned>& getY();
  
  void putX(vector<unsigned>& X);
  void putY(vector<unsigned>& Y);

  void printX(void);
  void printY(void);

  unsigned getSize(void);
};
