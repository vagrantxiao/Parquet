#include "command_line.h"
#include "UTIL/paramproc.h"
#include <iostream>
#include <string.h>
#include <time.h>
using namespace std;

Command_Line::Command_Line (int argc, const char *argv[]) : getSeed(0),
              budgetTime(0), softBlocks(0), initQP(0), seed(0), iterations(0), 
	      seconds(0), plot(0), savePl(0), saveCapo(0),takePl(0), 
	      timeInit(30000), timeCool(0.01), reqdAR(-9999), minWL(0)
{
        StringParam argInfile ("i", argc, argv);
	StringParam plOutFile ("savePl", argc, argv);
	StringParam saveCapoFile ("saveCapo", argc, argv);
	
	BoolParam help1 ("h", argc, argv);
	BoolParam help2 ("help", argc, argv);
        NoParams  noParams(argc,argv);  // this acts as a flag
    	IntParam  fixSeed ("s",argc,argv);
	IntParam  numberOfRuns("n",argc,argv);	
	DoubleParam timeReq("t",argc,argv);

	
	DoubleParam timeInit_("timeInit",argc,argv);
	DoubleParam timeCool_("timeCool",argc,argv);
	DoubleParam reqdAR_("AR",argc,argv);
	BoolParam   minWL_("minWL",argc,argv);
	BoolParam softBlocks_("soft", argc, argv);
	BoolParam initQP_("initQP", argc, argv);
	
	BoolParam plot_("plot",argc,argv);
	BoolParam plotNoNets_("plotNoNets", argc, argv);
	BoolParam plotNoSlacks_("plotNoSlacks", argc, argv);
	BoolParam plotNoNames_("plotNoNames",argc,argv);
	BoolParam takePl_("takePl",argc,argv);


	if (noParams.found() || help1.found() || help2.found())
	{
		printHelp ();
		exit (0);
	}
		
	// now set up member vars
	string temp;
	temp=argInfile;
	if (argInfile.found())
		strcpy(inFileName,temp.c_str());
	else
	{
		strcpy(inFileName,"TESTS/ami49");
	}

	if(plOutFile.found())
        {
	  strcpy(outPlFile, plOutFile);
	  savePl = 1;
	}
		
	if(saveCapoFile.found())
        {
	  strcpy(capoBaseFile, saveCapoFile);
	  saveCapo = 1;
	}
		
	if (fixSeed.found())
	{
		getSeed=false;
		seed = fixSeed;
	}
	else
		getSeed=true;//get sys time as seed

	if (numberOfRuns.found())
		iterations = numberOfRuns;
	else
		iterations = 1;
	
	if (timeReq.found())
	{
		budgetTime=true;//limit number of runs
		seconds = timeReq;
	}
	else
		budgetTime=false;

	  
	if(timeInit_.found())
	  timeInit = timeInit_;
	  
	if(timeCool_.found())
	  timeCool = timeCool_;
	  
	if(reqdAR_.found())
	  reqdAR = reqdAR_;   //default -9999 means no fixed outline desired
	  
	if(minWL_.found())
	  minWL = 1;

	if(takePl_.found())
	  takePl = 1;

	if(softBlocks_.found())
	  softBlocks = 1;
	  
        if(initQP_.found())
	  initQP = 1;
 
	if(plot_.found() || plotNoNets_.found() || plotNoSlacks_.found() ||
	   plotNoNames_.found())
	  plot = 1;
	
	plotNoNets = plotNoNets_;
	plotNoSlacks = plotNoSlacks_;
	plotNoNames = plotNoNames_;

	printAnnealerParams();
}

void Command_Line::printHelp ()
{
	cerr<<"FPTest.exe \n-i filename   (default is TESTS/ami49)\n"
		<<"-s int        (give a fixed seed)\n"
		<<"-n int        (determine number of runs. default 1)\n"
		<<"-t double     (set a time limit on the annealing run)\n"
		<<"-savePl filename(save .pl file of solution)\n"
		<<"-saveCapo basefilename (save design in Capo format)\n"
		<<"-plot         (plot the output solution to out.gpl file)\n"
		<<"-plotNoNets   (plot without the nets)\n"
		<<"-plotNoSlacks (plot without slacks info)\n"
		<<"-plotNoNames  (plot without name of blocks)\n\n"
		<<"-timeInit double  (annealing initial time: default 30000)\n"
		<<"-timeCool double  (annealing cool time: default 0.01\n"
		<<"-AR double  (required Aspect Ratio of fixed outline: default no Fixed Outline)\n"
		<<"-minWL        (minimize WL default turned off)\n"
	        <<"-soft         (soft Blocks present in input default no)\n"
//		<<"-initQP       (start the annealing with a QP solution)\n"
//		<<"-takePl       (take a placement and convert to sequence pair for use as initial solution)\n"
		<<endl;
}

void Command_Line::printAnnealerParams()
{
  cout<<"Annealer Params: "<<endl;
  cout<<"\tinitial Time      "<<timeInit<<endl;
  cout<<"\tcooling Time      "<<timeCool<<endl;
  cout<<"\treqd Aspect Ratio "<<reqdAR<<" (-9999 means no fixed shape)"<<endl;
  cout<<"\tminimize WL       "<<minWL<<endl<<endl;
}
