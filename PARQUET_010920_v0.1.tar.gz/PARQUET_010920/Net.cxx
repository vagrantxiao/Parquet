#include "FPcommon.h"
#include "Net.h"

void pin::changeOrient(ORIENT newOrient)
{
  _orient = newOrient;
  if(newOrient == N)
    {
      _offset.x = _origOffset.x;
      _offset.y = _origOffset.y;
    }
  else if(newOrient == E)
    {
      _offset.x = -1*_origOffset.y;
      _offset.y = _origOffset.x;
    }
  else if(newOrient == S)
    {
      _offset.x = -1*_origOffset.x;
      _offset.y = -1*_origOffset.y;
    }
  else if(newOrient == W)
    {
      _offset.x = _origOffset.y;
      _offset.y = -1*_origOffset.x; 
    }
  else if(newOrient == FN)
    {
      _offset.x = -1*_origOffset.x;
      _offset.y = _origOffset.y;
    }
  else if(newOrient == FE)
    {
      _offset.x = _origOffset.y;
      _offset.y = _origOffset.x;
    }
  else if(newOrient == FS)
    {
      _offset.x = _origOffset.x;
      _offset.y = -1*_origOffset.y;
    }
  else if(newOrient == FW)
    {
      _offset.x = _origOffset.y;
      _offset.y = _origOffset.x;
    }
  else
    {
      cout<<"ERROR in changeOrient "<<endl;
    }
}
