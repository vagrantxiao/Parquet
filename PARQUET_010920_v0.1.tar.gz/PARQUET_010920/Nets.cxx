#include "FPcommon.h"
#include "Nets.h"
#include "Nodes.h"

Nets::Nets(char* baseName)
{
  char basefile[100];
  strcpy(basefile,baseName);
  char fnameNets[100];
  strcpy(fnameNets,basefile);
  strcat(fnameNets,".nets");
  parseNets(fnameNets);
}

void Nets::parseNets(char* fnameNets)
{
  char block_name[100];
  ifstream nets(fnameNets);
  char tempWord1[1000];
  char netName[100];
  double poffsetX;
  double poffsetY;
  int netIndex = 0;
  int numNets = 0;
  int numPins;
  unsigned netDegree=0;
  unsigned netCtr=0;

  Net tempEdge;

  if(!nets)
   {
    cout<<"ERROR: .nets file could not be opened successfully"<<endl;
    return;
   }
  skiptoeol(nets);
  while(!nets.eof())
    {
      nets>>tempWord1;
      if(!(strcmp(tempWord1,"NumNets")))
        break;
    }
  nets>>tempWord1;
  nets>>numNets;
  while(!nets.eof())
    {
      nets>>tempWord1;
      if(!(strcmp(tempWord1,"NumPins")))
        break;
    }
  nets>>tempWord1;
  nets>>numPins;
  
  while(!nets.eof())
    {
      nets>>tempWord1;
      if(!(strcmp(tempWord1,"NetDegree")))
        break;
    }
  nets>>tempWord1;
  nets>>netDegree;

  eatblank(nets);
  if(nets.peek() == '\n' || nets.peek() == '\r')
    {
      sprintf(netName,"N%d",netIndex);
    }
  else  //netName present
    {
      nets>>netName;
    }
  skiptoeol(nets);
  tempEdge.putName(netName);
  
  while(!nets.eof())
    { 
      eatblank(nets);
      if(nets.eof())
        break;
      if(nets.peek()=='#')
	eathash(nets);
      else
	{
	  eatblank(nets);
	  if(nets.peek() == '\n' || nets.peek() == '\r')
	    {
	      nets.get();
	      continue;
	    }
	    
	  nets>>block_name;
	  nets>>tempWord1;
	  
	  if(!strcmp(tempWord1,"B"))
	    {
	      eatblank(nets);
	      if(nets.peek()=='\n' || nets.peek()=='\r')
		{
		  nets.get();
		  //put terminal info in vector
		  pin tempPin(block_name,true,0,0,netIndex);
	          tempEdge.addNode(tempPin);
		  //cout<<block_name<<"\t"<<tempWord1<<"\t"<<endl;
		  ++netCtr;
		  continue;
		}
	      else
		{
		  nets>>tempWord1;
		  if(!strcmp(tempWord1,":"))
		    {
		      eatblank(nets);
		    }
		  else
		    cout << "error in parsing"<<endl;
		  
		  if(nets.peek()!='%')
		    {cout<<"expecting %"<<endl;}
		  else
		    {
		      nets.get();
		      nets>>poffsetX;
		      eatblank(nets);
		      nets.get();
		      nets>>poffsetY;
		      nets.get();
		      //convert from %
		      poffsetX /= 100;
		      poffsetY /= 100;
		      //put block info here
		      pin tempPin(block_name,false,poffsetX,poffsetY,netIndex);
		      tempEdge.addNode(tempPin);
//cout<<block_name<<"\t"<<tempWord1<<"\t"<<poffsetX<<"\t"<<poffsetY<<endl;
		      ++netCtr;
		    }
		}
	    }
	  
	  else if(!strcmp(block_name,"NetDegree"))//new net starts
	    {
	      tempEdge.putIndex(netIndex);
	      _nets.push_back(tempEdge);

	      if(netCtr != netDegree)
	        { 
		  cout<<"ERROR in parsing .nets file netDegree do not match with no: of pins\n"<<endl;
                }
	      netCtr = 0;
              tempEdge.clean();
	      netIndex++;
              
	      nets>>netDegree;
              eatblank(nets);
              if(nets.peek() == '\n' || nets.peek() == '\r')
                {
                  sprintf(netName,"N%d",netIndex);
                }
              else  //netName present
                { 
                  nets>>netName;
                }
              skiptoeol(nets);
              tempEdge.putName(netName);
	    }
	}
    }
  nets.close();
  
  //put the last net info inside
  tempEdge.putIndex(netIndex);
  _nets.push_back(tempEdge);
  ++netIndex;

  if(netIndex != numNets)
    cout<<"Error in parsing .nets file. Number of nets do not tally "<<netIndex<<" vs "<<numNets<<endl;

/*
  int actNumPins = getNumPins();
  if(numPins != actNumPins)
    cout<<"Error in parsing .nets file. Number of pins do not tally "<<actNumPins<<" vs "<<numPins<<endl;
*/ 
}

void Nets::updateNodeInfo(Nodes& nodes)
{
  itNet net;
  itPin pin;
  itNode node;
  bool brokeFromLoop=0;
  for(net = _nets.begin(); net != _nets.end(); net++)
    {
      for(pin = net->pinsBegin(); pin != net->pinsEnd(); pin++)
        {
	  brokeFromLoop = 0;
	  for(node = nodes.nodesBegin(); node != nodes.nodesEnd(); node++)
	    {
	      if(strcmp(node->getName(), pin->getName()) == 0)
	        {
		  pin->putNodeIndex(node->getIndex());
		  pin->putType(0);
		  brokeFromLoop = 1;
		  break;
		}
	    }
	  if(!brokeFromLoop)
	  {
           for(node = nodes.terminalsBegin(); node != nodes.terminalsEnd(); 
	       node++)
	    {
	      if(strcmp(node->getName(), pin->getName()) == 0)
		{
		  pin->putNodeIndex(node->getIndex());
		  pin->putType(1);
		  brokeFromLoop = 1;
		  break;
		}
            }
	    if(!brokeFromLoop)
	      cout<<"ERROR: Node "<<pin->getName()<<" not found in updateNodeInfo"<<endl;
	  }
	}
    }
}


int Nets::getNumPins(void)
{
  itNet net;
  int numPins = 0;
  for(net = netsBegin(); net != netsEnd(); ++net)
   {
     numPins += net->_pins.size();
   }
  return numPins;
}
