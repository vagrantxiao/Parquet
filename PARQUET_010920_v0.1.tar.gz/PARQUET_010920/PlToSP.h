#include <fstream.h>
#include <vector>
#include <algorithm>
#include <math.h>
#include <stdlib.h>

using namespace std;

class Pl2SP
{
  private:
    vector<double> _xloc;
    vector<double> _yloc;
    vector<double> _widths;
    vector<double> _heights;

    vector<unsigned> _X;
    vector<unsigned> _Y;
    
  public:
    Pl2SP(vector<double>& xloc, vector<double>& yloc, vector<double>& widths,
          vector<double>& heights);

    ~Pl2SP() {}
    
    vector<unsigned>& getXSP(void)
     { return _X; }
     
    vector<unsigned>& getYSP(void)
     { return _Y; }

    void print(void);

};

struct RowElem
{
  unsigned index;
  double xloc;
};


struct less_mag 
{
  bool operator()(const RowElem &elem1, const RowElem &elem2) 
  { return(elem1.xloc < elem2.xloc); }
};




