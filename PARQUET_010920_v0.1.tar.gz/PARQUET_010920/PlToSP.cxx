#include "FPcommon.h"
#include "PlToSP.h"

Pl2SP::Pl2SP(vector<double>& xloc, vector<double>& yloc, vector<double>& widths,
             vector<double>& heights): _xloc(xloc), _yloc(yloc), _widths(widths)
	     , _heights(heights)
{
  unsigned size = _xloc.size();
  if(_yloc.size() != size || _widths.size() != size || _heights.size() != size)
    cout<<"ERROR: in Pl2SP. Sizes do not match"<<endl;

  double rowHeight = 1e100;
  double maxYLoc = -1e100;
  
  for(unsigned i=0; i<size; ++i)
   {
     if(rowHeight > _heights[i])
       rowHeight = _heights[i];
       
     if(maxYLoc < _yloc[i])
       maxYLoc = _yloc[i];
   }

  unsigned numRows = unsigned(ceil(maxYLoc/rowHeight)+1);

  //snap to y grid here
  for(unsigned i=0; i<size; ++i)
   {
     unsigned reqdRow = unsigned(rint(_yloc[i]/rowHeight));
     _yloc[i] = reqdRow*rowHeight;
   }
  
  vector< vector<RowElem> > rows;
  vector<RowElem> singleRow;
  RowElem tempRE;
  
  double currHeight = 0;
  
  for(unsigned i=0; i<numRows; ++i)
   {
     for(unsigned j=0; j<size; ++j)
       { 
         if(fabs(_yloc[j]-currHeight)<0.0001)
	   {
	     tempRE.index = j;
	     tempRE.xloc = _xloc[j];
	     singleRow.push_back(tempRE);
	   }
       }
       
     currHeight += rowHeight;

     std::stable_sort(singleRow.begin(), singleRow.end(), less_mag());
     rows.push_back(singleRow);
     singleRow.clear();
   }

   //form the X and Y sequence pairs now
   for(unsigned i=0; i<rows.size(); ++i)
    {
      for(unsigned j=0; j<rows[i].size(); ++j)
        {
	  _Y.push_back(rows[i][j].index);
	}
    }
   for(int i=rows.size()-1; i>=0; --i)
    {
      for(unsigned j=0; j<rows[i].size(); ++j)
        {
	  _X.push_back(rows[i][j].index);
	}
    }

  if(_X.size() != _xloc.size() || _Y.size() != _xloc.size())
   {
    cout<<"ERROR: generated sequence pair of not correct sizes "<<_X.size()<<" & "<<_Y.size()<<" vs "<<size<<endl;
    print();
   }
    
}

void Pl2SP::print()
{
  cout<<"XSequence Pair"<<endl;
  for(unsigned i=0; i<_X.size(); ++i)
    cout<<_X[i]<<"  ";
  cout<<endl<<"YSequence Pair"<<endl;
  for(unsigned i=0; i<_Y.size(); ++i)
    cout<<_Y[i]<<"  ";
}
