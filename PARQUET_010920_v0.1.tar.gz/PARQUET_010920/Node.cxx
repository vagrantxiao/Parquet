#include "FPcommon.h"
#include "Nets.h"
#include "Node.h"

Node:: Node(char* block_name,double block_area,double minAr,double maxAr,
	    int index,bool type)
   : _area(block_area),_minAr(minAr),_maxAr(maxAr),_orient(N),_slackX(0),
     _slackY(0),_index(index),_type(type)
   {
     strcpy(_name,block_name);
     _placement.x=0;
     _placement.y=0;
     _width = sqrt(_area/_minAr);   //by default orientation is N
     _height = _minAr*_width;
     _origWidth = _width;
     _origHeight = _height;
   }

//default ctor
Node::Node()
  : _area(0),_minAr(0),_maxAr(0),_orient(N),_slackX(0),_slackY(0),_index(0),
    _type(true)
{
  strcpy(_name,"");
  _placement.x=0;
  _placement.y=0;
  _height = 0;
  _width = 0;
}

void Node::changeOrient(ORIENT newOrient, Nets& nets)
{
  if(_orient == newOrient)
    return;
  
  if(_orient%2 != newOrient%2)
    {
      double tempHeight = _height;
      _height = _width;
      _width = tempHeight;
    }

  //update the pinoffsets of the netlist now
  itNodePin itP;
  for(itP = _pins.begin(); itP != _pins.end(); ++itP)
    {
      pin& netPin = nets.getNet(itP->netIndex).getPin(itP->pinOffset);
      netPin.changeOrient(newOrient);
    }
  _orient = newOrient;

}

void Node::syncOrient(Nets& nets)
{
  //update the heights and widths only if not updated earlier in parsePl
  if(_width == _origWidth && _height == _origHeight)
    {
     if(int(_orient)%2 == 1)  //needs swap of height and width
      {
        double tempHeight = _height;
        _height = _width;
        _width = tempHeight;
      }
    }
    
  //update the pinoffsets of the netlist now
  itNodePin itP;
  for(itP = _pins.begin(); itP != _pins.end(); ++itP)
    {
      pin& netPin = nets.getNet(itP->netIndex).getPin(itP->pinOffset);
      netPin.changeOrient(_orient);
    }
}
