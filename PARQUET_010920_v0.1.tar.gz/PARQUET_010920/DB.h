#include <vector>
#include <algorithm>
#include <math.h>
#include <stdlib.h>
#include "Nets.h"
#include "Nodes.h"


class DB
{
 private:
  Nodes* _nodes;
  Nets* _nets;

 public:
  DB(char* baseName);
  ~DB();

  unsigned getNumNodes(void);
  Nodes* getNodes(void);
  Nets* getNets(void);

  vector<double> getNodeWidths();
  vector<double> getNodeHeights();
  vector<double> getXLocs();
  vector<double> getYLocs();

  double getNodesArea(void);

  void updatePlacement(vector<double>& xloc, vector<double>& yloc);
  void updateSlacks(vector<double>& xSlack, vector<double>& ySlack);
  void plot(char* fileName, double area, double whitespace, double aspectRatio,
      double time, double HPWL, bool plotSlacks, bool plotNets, bool plotNames);

  void saveCapo(char *baseFileName, double reqdAR);  //save the data in Capo format
  void saveCapoNets(char* baseFileName);
	
  double evalHPWL(void);  //assumes that placement is updated
  double evalArea(void);  //assumes that placement is updated

  void shiftDesign(Point& offset); //shift the entire placement by an offset
};
