#ifndef COMMAND_LINE_H
#define COMMAND_LINE_H
#include <string>

class Command_Line
{
	public:
		Command_Line (int argc, const char *argv[]);
				
		// public member variables to store params
		bool getSeed, budgetTime;
		bool softBlocks;
		bool initQP;     //initialize a QP soln
		char inFileName[200];
		char outPlFile [200];
		char capoBaseFile [200];
		
		int seed;      //fixed seed
		int iterations;//number of runs
		double seconds;
                bool plot;             //plot to out.gpl
		bool plotNoNets;       //do not plot nets 
		bool plotNoSlacks;     //do not plot slacks
		bool plotNoNames;      //do not plot names
                bool savePl;           //save .pl file as output
		bool saveCapo;         //save files in Capo format

		bool takePl;           //takes a Placement and converts it 
				       //to sequence pair for initial soln
		//Annealer performance parameters next
		double timeInit;     //initial temperature default 30000
		double timeCool;     //cooling temperature default 0.01
		double reqdAR;       //required Aspect Ratio of fixed outline
				     //default -9999(means no fixed outline
				     //desired)
		bool minWL;          //whether HPWL minimization desired
		
		
	public:
		// Print usage info. to cerr
		void printHelp ();
		//print the Annealer params
		void printAnnealerParams();
		
};

#endif // COMMAND_LINE_H
