#include "SPeval.h"

SPeval::SPeval(const vector<double> heights, const vector<double> widths)
{
  _heights=heights;
  _widths=widths;
  unsigned size = heights.size();
  _match.resize(size);
  _L.resize(size);
  _reverseSeq.resize(size);
  _X.resize(size);
  _Y.resize(size);
  xloc.resize(size);
  yloc.resize(size);
  xSlacks.resize(size);
  ySlacks.resize(size);
  xlocRev.resize(size);
  ylocRev.resize(size);
}

double SPeval::_lcsCompute(const vector<unsigned>& X,
			   const vector<unsigned>& Y,
			   const vector<double>& weights,
			   vector<unsigned>& match,
			   vector<double>& P,
			   vector<double>& L
			   )
{
  unsigned size = X.size();
  for(unsigned i=0;i<size;++i)
    {
      match[Y[i]]=i;
      L[i]=0;
    }
  
  double t;
  unsigned j;
  for(unsigned i=0;i<size;++i)
    {
      unsigned p = match[X[i]];
      P[X[i]]=L[p];
      t = P[X[i]]+weights[X[i]];
      
      for(j=p;j<size;++j)
	{
	  if(t>L[j])
	    L[j]=t;
	  else
	    break;
	}
    }
  return L[size-1];
}


double SPeval::xEval()
{
  fill(_match.begin(),_match.end(),0);
  return _lcsCompute( _X, _Y, _widths, _match, xloc, _L);
}

double SPeval::yEval()
{
  _reverseSeq = _X;
  reverse(_reverseSeq.begin(),_reverseSeq.end());
  fill(_match.begin(),_match.end(),0);
  return _lcsCompute( _reverseSeq, _Y, _heights, _match, yloc, _L);
}

void SPeval::evaluate(vector<unsigned>& X, vector<unsigned>& Y)
{
  _X = X;
  _Y = Y;
  xSize = xEval();
  ySize = yEval();
}



void SPeval::changeWidths(vector<double>& widths)
{
  _widths = widths;
}

void SPeval::changeHeights(vector<double>& heights)
{
  _heights = heights;
}

void SPeval::changeNodeWidth(unsigned index, double width)
{
  _widths[index] = width;
}

void SPeval::changeNodeHeight(unsigned index, double height)
{
  _heights[index] = height;
}

void SPeval::changeOrient(unsigned index)
{
  double tempWidth = _heights[index];
  _heights[index] = _widths[index];
  _widths[index] = tempWidth;
}





double SPeval::_lcsReverseCompute(const vector<unsigned>& X,
				  const vector<unsigned>& Y,
				  const vector<double>& weights,
				  vector<unsigned>& match,
				  vector<double>& P,
				  vector<double>& L
				  )
{
  unsigned size = X.size();
  for(unsigned i=0;i<size;++i)
    {
      match[Y[i]]=i;
      L[i]=0;
    }
  
  double t;
  int j;
  for(int i=size-1;i>=0;--i)
    {
      unsigned p = match[X[i]];
      P[X[i]]=L[p];
      t = P[X[i]]+weights[X[i]];
      
      for(j=p;j>=0;--j)
	{
	  if(t>L[j])
	    L[j]=t;
	  else
	    break;
	}
    }
  return L[size-1];
}


double SPeval::xEvalRev()
{
  fill(_match.begin(),_match.end(),0);
  return _lcsReverseCompute( _X, _Y, _widths, _match, xlocRev, _L);
}

double SPeval::yEvalRev()
{
  _reverseSeq = _X;
  reverse(_reverseSeq.begin(),_reverseSeq.end());
  fill(_match.begin(),_match.end(),0);
  return _lcsReverseCompute( _reverseSeq, _Y, _heights, _match, ylocRev, _L);
}

void SPeval::evalSlacks(vector<unsigned>& X, vector<unsigned>& Y)
{
  _X = X;
  _Y = Y;
  xSize = xEval();
  ySize = yEval();
  xEvalRev();
  yEvalRev();

  for(unsigned i=0; i<_X.size(); ++i)
    {
      xlocRev[i] = xSize - xlocRev[i] - _widths[i];
      ylocRev[i] = ySize - ylocRev[i] - _heights[i];
      xSlacks[i] = (xlocRev[i] - xloc[i])*100/xSize;
      ySlacks[i] = (ylocRev[i] - yloc[i])*100/ySize;
    }

}
