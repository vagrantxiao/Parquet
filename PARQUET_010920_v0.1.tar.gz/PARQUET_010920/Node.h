#include <vector>
#include <algorithm>
#include <math.h>
#include <stdlib.h>

using namespace std;
class Nets;

struct NodePin
{
  unsigned netIndex;
  unsigned pinOffset;
};

typedef std::vector<NodePin>::iterator itNodePin;

class Node
{
 private:
  char _name[100];
  double _area;
  double _minAr;
  double _maxAr;
  double _origWidth;
  double _origHeight;
  double _width;
  double _height;
  ORIENT _orient;          //N,E,S,W,FN.FE,FS or FW. N on initialization
  double _slackX;
  double _slackY;
  int _index;
  bool _type;              //0 normal node,1 pad
  Point _placement;
  vector<NodePin> _pins;       //all the pins of this node

 public:
  //ctors
   Node(char* block_name,double block_area,double minAr,double maxAr,
	   int index,bool type);
   Node();


   bool getType()
     { return _type;}
   int getIndex(void)
     {return _index;} 
   ORIENT getOrient(void)
     {return _orient;}
   double getHeight(void)
     {return _height;}
   double getWidth(void)
     {return _width;}
   char* getName(void)
     {return _name;}
   double getX(void)
     {return _placement.x;}
   double getY(void)
     {return _placement.y;}
   double getslackX(void)
     {return _slackX;}
   double getslackY(void)
     {return _slackY;}
   double getminAR(void)
     {return _minAr;}
   double getmaxAR(void)
     {return _maxAr;}
   double getArea(void)
     {return _area;}

   itNodePin pinsBegin()
     {return _pins.begin(); }
   itNodePin pinsEnd()
     {return _pins.end(); }
   unsigned getDegree()
     { return _pins.size(); }
   
   void putWidth(double w)
     {_width=w;}
   void putHeight(double h)
     {_height=h;}
   void putX(double x)
     {_placement.x=x;}
   void putY(double y)
     {_placement.y=y;}
   void putslackX(double x)
     {_slackX=x;}
   void putslackY(double y)
     {_slackY=y;}
   void addPin(NodePin& pinTemp)
     {_pins.push_back(pinTemp);}
   void putOrient(ORIENT newOrient)    //to be used only during initialization
     { _orient = newOrient; }          //else use changeOrient
   
   void changeOrient(ORIENT newOrient, Nets& nets);
   void syncOrient(Nets& nets);
};
