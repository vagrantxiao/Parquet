#include "FPcommon.h"
#include "DB.h"

//ctor
DB::DB(char* baseName)
{
  _nodes = new Nodes(baseName);
  _nets =  new Nets(baseName);
  _nets->updateNodeInfo(*_nodes);
  _nodes->updatePinsInfo(*_nets);
}

DB::~DB()
{
  if(_nodes) delete _nodes;
  if(_nets) delete _nets;
}

Nodes* DB::getNodes(void)
{ return _nodes; }

Nets* DB::getNets(void)
{ return _nets; }

unsigned DB::getNumNodes(void)
{
  return _nodes->getNumNodes();
}

vector<double> DB::getNodeWidths(void)
{
  return _nodes->getNodeWidths();
}

vector<double> DB::getNodeHeights(void)
{
  return _nodes->getNodeHeights();
}

vector<double> DB::getXLocs(void)
{
  return _nodes->getXLocs();
}

vector<double> DB::getYLocs(void)
{
  return _nodes->getYLocs();
}

double DB::getNodesArea(void)
{
  double area=_nodes->getNodesArea();
  return area;
}

void DB::updatePlacement(vector<double>& xloc, vector<double>& yloc)
{
  for(unsigned i=0; i<xloc.size(); ++i)
    {
      _nodes->getNode(i).putX(xloc[i]);
      _nodes->getNode(i).putY(yloc[i]);
    }
}
void DB::updateSlacks(vector<double>& xSlack, vector<double>& ySlack)
{
  for(unsigned i=0; i<xSlack.size(); ++i)
    {
      _nodes->getNode(i).putslackX(xSlack[i]);
      _nodes->getNode(i).putslackY(ySlack[i]);
    }  
}

double DB::evalHPWL(void)
{
  itNet net;
  itPin pin;
  unsigned nodeIndex;
  BBox netBBox;
  Point tempPoint;
  double HPWL=0;
  double width;
  double height;
  double absOffsetX;
  double absOffsetY;
  double xloc;
  double yloc;
  
  for(net = _nets->netsBegin(); net != _nets->netsEnd(); ++net)
    {
      for(pin = net->pinsBegin(); pin != net->pinsEnd(); ++pin)
        {
	  nodeIndex = pin->getNodeIndex();
	  if(!pin->getType())        //if not terminal
	   {
	    Node& node = _nodes->getNode(nodeIndex);
	    width = node.getWidth();
	    height = node.getHeight();
	    xloc = node.getX();
	    yloc = node.getY();
	   }			
	  else
	    {
	     Node& node = _nodes->getTerminal(nodeIndex);
	     width = node.getWidth();
	     height = node.getHeight();
	     xloc = node.getX();
	     yloc = node.getY();
	    }
	  absOffsetX = width/2 + (pin->getXOffset()*width);
	  absOffsetY = height/2 + (pin->getYOffset()*height);
	  
          tempPoint.x = xloc + absOffsetX;
	  tempPoint.y = yloc + absOffsetY;
	  netBBox.put(tempPoint);
	}
      if(netBBox.isValid())
      {
	//cout<<net->getName()<<" "<<netBBox.getHPWL()<<" "<<HPWL<<endl;
        HPWL += netBBox.getHPWL();
      }
      netBBox.clear();	
    }
  return HPWL;    
}

double DB::evalArea(void)
{
  BBox area;
  itNode node;
  Point P;
  for(node = getNodes()->nodesBegin(); node != getNodes()->nodesEnd(); ++node)
    {
      P.x = node->getX();
      P.y = node->getY();
      area.put(P);
      P.x = node->getX()+node->getWidth();
      P.y = node->getY()+node->getHeight();
      area.put(P);
    }
  return(area.getXSize()*area.getYSize());
}

void DB::plot(char* fileName, double area, double whitespace, 
	      double aspectRatio, double time, double HPWL, bool plotSlacks,
	      bool plotNets, bool plotNames)
{
  double x=0;
  double y=0;
  double w=0;
  double h=0;
  itNode it;

  cout<<"OutPut Plot file is "<<fileName<<endl;
  ofstream gpOut(fileName);


  gpOut<<"#Use this file as a script for gnuplot"<<endl;
  gpOut<<"#(See http://www.cs.dartmouth.edu/gnuplot_info.html for details)"<<endl;
  gpOut << "set nokey"<<endl;
									  
  gpOut << "set title ' "<<fileName<<" area= "<<area<<" WS= "<<whitespace<<"%"<<" AR= "<<aspectRatio<<" time= "<<time<<"s"<<" HPWL= "<<HPWL<<endl<<endl;

  gpOut<<"#   Uncomment these two lines starting with \"set\""<<endl ;
  gpOut<<"#   to save an EPS file for inclusion into a latex document"<<endl;
  gpOut << "# set terminal postscript eps color 10"<<endl;
  gpOut << "# set output \"out.eps\""<<endl<<endl<<endl;

  gpOut<<"#   Uncomment these two lines starting with \"set\""<<endl ;
  gpOut<<"#   to save a PS file for printing"<<endl;
  gpOut<<"# set terminal postscript portrait color 8"<<endl;
  gpOut << "# set output \"out.ps\""<<endl<<endl<<endl;

  if(plotNames)
  {
   for(it=_nodes->nodesBegin();it!=_nodes->nodesEnd();++it)
    {
     gpOut<<"set label \""<<it->getName()<<"\" at "<<it->getX()+it->getWidth()/4<<" , "<<it->getY()+it->getHeight()/4<<endl;
    }
   
   for(it=_nodes->terminalsBegin();it!=_nodes->terminalsEnd();++it)
    {
     gpOut<<"set label \""<<it->getName()<<"\" at "<<it->getX()+it->getWidth()/4<<" , "<<it->getY()+it->getHeight()/4<<endl;
    }
  }
	    
  
 if(plotSlacks)
   {
     for(it=_nodes->nodesBegin();it!=_nodes->nodesEnd();++it)
      {
        gpOut.precision(4);
        gpOut<<"set label \"x "<<it->getslackX()<<"\" at "<<it->getX()+it->getWidth()/6<<" , "<<it->getY()+it->getHeight()/2<<endl;
        gpOut<<"set label \"y "<<it->getslackY()<<"\" at "<<it->getX()+it->getWidth()/6<<" , "<<it->getY()+it->getHeight()*3/4<<endl;
      }
   }

 gpOut.precision(6);
 gpOut << "plot '-' w l, '-' w l 3";
 gpOut<<endl;

 for(it=_nodes->nodesBegin();it!=_nodes->nodesEnd();++it)
   {
     x=it->getX();
     y=it->getY();
     w=it->getWidth();
     h=it->getHeight();

     gpOut<<x<<" "<<y<<endl;
     gpOut<<x+w<<" "<<y<<endl;
     gpOut<<x+w<<" "<<y+h<<endl;
     gpOut<<x<<" "<<y+h<<endl;
     gpOut<<x<<" "<<y<<endl<<endl;
   }
 gpOut << "EOF"<<endl;

 if(plotNets)
 {
  double width;
  double height;
  double absOffsetX;
  double absOffsetY;
 
  itNet net;
  itPin netPin;
  for(net = _nets->netsBegin(); net != _nets->netsEnd(); ++net)
    {
      Point starPoint;
      starPoint.x = 0;
      starPoint.y = 0;
      unsigned netDegree = 0;
      for(netPin = net->pinsBegin(); netPin != net->pinsEnd(); netPin++)
        {
          Node node;
	  if(!netPin->getType())  //if not terminal
	    node = _nodes->getNode(netPin->getNodeIndex());
	  else
	    node = _nodes->getTerminal(netPin->getNodeIndex());

  	  width = node.getWidth();
          height = node.getHeight();
          absOffsetX = width/2 + (netPin->getXOffset()*width);
          absOffsetY = height/2 + (netPin->getYOffset()*height);
	  starPoint.x += node.getX() + absOffsetX;
	  starPoint.y += node.getY() + absOffsetY;
	  ++netDegree;
        }
      if(netDegree != 0)
        {
          starPoint.x /= netDegree;
  	  starPoint.y /= netDegree;
          for(netPin = net->pinsBegin(); netPin != net->pinsEnd(); netPin++)
            {
              Node node;
	      if(!netPin->getType())
	        node = _nodes->getNode(netPin->getNodeIndex());
	      else
	        node = _nodes->getTerminal(netPin->getNodeIndex());
              width = node.getWidth();
              height = node.getHeight();
              absOffsetX = width/2 + (netPin->getXOffset()*width);
              absOffsetY = height/2 + (netPin->getYOffset()*height);
              gpOut<<starPoint.x<<"  "<<starPoint.y<<endl;
	      gpOut<<node.getX()+absOffsetX<<"  "<<node.getY()+absOffsetY<<endl;
	      gpOut<<starPoint.x<<"  "<<starPoint.y<<endl<<endl;
	    }
        }
    }
 }
 gpOut << "EOF"<<endl<<endl; 
 gpOut << "pause -1 'Press any key' "<<endl;
 gpOut.close();  
}


void DB::saveCapo(char* baseFileName, double reqdAR)
{
  cout<<"Saving in Capo Format "<<baseFileName<<endl;
  _nodes->saveCapoNodes(baseFileName);
  _nodes->saveCapoPl(baseFileName);
  saveCapoNets(baseFileName);
  _nodes->saveCapoScl(baseFileName, reqdAR);

  //save the aux file now
  char fileName[100];
  strcpy(fileName, baseFileName);
  strcat(fileName, ".aux");
  ofstream aux(fileName);
  aux<<"RowBasedPlacement : "<<baseFileName<<".nodes "<<baseFileName<<".nets "<<
       baseFileName<<".scl "<<baseFileName<<".pl "<<endl;
  aux.close();     
}


void DB::saveCapoNets(char* baseFileName)
{
  Nets* nets;
  nets = getNets();
  double absOffsetX;
  double absOffsetY;
  double width;
  double height;
  int nodeIndex;
  
  char fileName[100];
  strcpy(fileName, baseFileName);
  strcat(fileName, ".nets");
  ofstream file(fileName);

  file<<"UCLA nets   1.0"<<endl<<endl<<endl;
  file<<"NumPins : "<<nets->getNumPins()<<endl<<endl;
  
  itNet net;
  itPin pin;
  for(net = nets->netsBegin(); net != nets->netsEnd(); ++net)
   {
    file<<"NetDegree : "<<net->_pins.size()<<"\t"<<net->getName()<<endl;
    for(pin = net->pinsBegin(); pin != net->pinsEnd(); ++pin)
     {
	  nodeIndex = pin->getNodeIndex();
	  if(!pin->getType())        //if not terminal
	   {
	    Node& node = _nodes->getNode(nodeIndex);
	    width = node.getWidth();
	    height = node.getHeight();
	   }			
	  else
	    {
	     Node& node = _nodes->getTerminal(nodeIndex);
	     width = node.getWidth();
	     height = node.getHeight();
	    }
	  absOffsetX = (pin->getXOffset()*width);
	  absOffsetY = (pin->getYOffset()*height);
	  
          file<<"\t"<<pin->getName()<<" B : \t"<<absOffsetX<<"\t "<<absOffsetY<<endl;
     }
   }
 file.close();
}

void DB::shiftDesign(Point& offset)
{
 itNode node;
 for(node = _nodes->nodesBegin(); node != _nodes->nodesEnd(); ++node)
  {
    node->putX(node->getX() + offset.x);
    node->putY(node->getY() + offset.y);
  }
}
